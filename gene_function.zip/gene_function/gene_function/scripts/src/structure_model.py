import pytorch_lightning as pl
import torch
import torch.nn as nn
import h5py as h5
import pickle

import pandas as pd
import numpy as np

from src.utils import performance_assessment
from src.utils_deepgoplus import update_scores
from IPython import embed
#from flash.core.optimizers import LinearWarmupCosineAnnealingLR

##########################
## FOR MASKED LOSS #######
##########################
class StructureNetwork_masked(pl.LightningModule):
    def __init__(self,config,transfer_terms=None):
        super().__init__()
        self.config = config
        self.__set_masks(transfer_terms)
        self.lm = LanguageModel(config)
        
        self.aa_embedding = nn.Linear(26,1024,bias=False)
        self.gcn1 = GCNLayer(config, 1, 512)
        self.gcn2 = GCNLayer(config, 2, 512)
        self.gcn3 = GCNLayer(config, 3, 512)
        self.fc1 = nn.Linear(3*512,1024)
        self.activation = eval(f"nn.{self.config['activation']}()")
        self.dropout = nn.Dropout(p=config['p'])
        #self.fc2 = nn.Linear(1024,config['output_dim'])
        #self.sigmoid = nn.Sigmoid()
        self.fc2 = nn.Linear(1024,2*config['output_dim']) # original deepFRI output layer
        self.softmax = nn.Softmax(dim=-1)                 # original deepFRI output layer

        self.criterion = nn.BCELoss()

        # Load the weights for transfer learning
        self.__set_weights()
        self.save_hyperparameters()

    def __set_masks(self,transfer_terms):
        with open(self.config['deepfri_terms'],'rb') as f:
            self.deepf_terms = pickle.load(f)
        mask_terms_transfer = transfer_terms[transfer_terms.terms.isin(self.deepf_terms.terms)].terms.values
        self.mask_terms_dgop = self.deepf_terms[self.deepf_terms.terms.isin(transfer_terms.terms)].terms.values
        self.label_permutation = [list(mask_terms_transfer).index(t) for t in self.mask_terms_dgop]
        self.anti_mask = self.deepf_terms[~self.deepf_terms.terms.isin(self.mask_terms_dgop)].index.values
        self.mask = self.deepf_terms[self.deepf_terms.terms.isin(self.mask_terms_dgop)].index.values
        self.label_mask = transfer_terms[transfer_terms.terms.isin(self.mask_terms_dgop)].index.values[self.label_permutation]
        self.all_terms = self.deepf_terms.terms.values

    def __set_weights(self):
        weights = h5.File(self.config['model_file'])['model_weights']
        self.aa_embedding.weight = nn.Parameter(torch.FloatTensor(weights['AA_embedding/AA_embedding/kernel:0'][:]).permute(1,0))
        for param in self.aa_embedding.parameters():
            param.requires_grad = False
        
        self.fc1.weight = nn.Parameter(torch.FloatTensor(weights['dense/dense/kernel:0'][:]).permute(1,0))
        self.fc1.bias = nn.Parameter(torch.FloatTensor(weights['dense/dense/bias:0'][:]))

        self.fc2.weight = nn.Parameter(torch.FloatTensor(weights['labels/labels/dense_1/kernel:0'][:,::2]).permute(1,0))
        self.fc2.bias = nn.Parameter(torch.FloatTensor(weights['labels/labels/dense_1/bias:0'][::2]))

    def forward(self,x):
        A,S = x
        s_1 = self.lm(S)
        s_2 = self.aa_embedding(S)
        s = self.activation(s_1 + s_2)
        a_1 = self.gcn1((A,s))
        a_2 = self.gcn2((A,a_1))
        a_3 = self.gcn3((A,a_2))
        z = torch.concat([a_1,a_2,a_3],dim=-1)
        z = torch.sum(z,axis=1)
        z = self.fc1(z)
        z = self.activation(z)
        z = self.dropout(z)
        z = self.fc2(z)
        #out = self.sigmoid(z)
        out = self.softmax(z)
        return out 

    def training_step(self,batch,batch_idx):
        x,y = batch
        y_hat = self.forward(x)
        loss = self.criterion(y_hat[:,self.mask],y[:,self.label_mask])
        self.log('train_loss',loss)
        return loss

    def validation_step(self,batch,batch_idx):
        x,y = batch
        y_hat = self.forward(x)
        loss = self.criterion(y_hat[:,self.mask],y[:,self.label_mask])
        self.log('val_loss',loss,on_epoch=True)

    def test_step(self,batch,batch_idx):
        x,y = batch
        y_hat = self.forward(x)
        return {'y_hat':y_hat,'y':y}
    
    def test_epoch_end(self, outputs):
        y = torch.concat([x['y'] for x in outputs],dim=0).detach().cpu().numpy()
        y_hat = torch.concat([x['y_hat'] for x in outputs],dim=0).detach().cpu().numpy()

        y_hat_hier = update_scores(pd.DataFrame(data=y_hat,columns=self.deepf_terms.terms.values.flatten()), self.config['go_fn'])
        performance_assessment(y_hat_hier.loc[:,self.mask_terms_dgop].values,y[:,self.label_mask])

    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=self.config['lr'],weight_decay=self.config['weight_decay'])


class ExtractedStructureNetwork_masked(pl.LightningModule):
    def __init__(self,config,config_train,transfer_terms=None):
        super().__init__()
        self.config = config
        self.config_train = config_train
        self.__set_masks(transfer_terms)
        self.fc1 = nn.Linear(3*512,1024)
        self.activation = eval(f"nn.{self.config['activation']}()")
        self.dropout = nn.Dropout(p=config['p'])
        # self.fc2 = nn.Linear(1024,config['output_dim'])
        # self.sigmoid = nn.Sigmoid()
        self.fc2 = nn.Linear(1024,2*config['output_dim'])
        self.softmax = nn.Softmax(dim=-1)

        self.criterion = nn.BCELoss()

        # Load the weights for transfer learning
        self.__set_weights()
        self.save_hyperparameters()

    def __set_masks(self,transfer_terms):
        with open(self.config['deepfri_terms'],'rb') as f:
            self.deepf_terms = pickle.load(f)
        mask_terms_transfer = transfer_terms[transfer_terms.terms.isin(self.deepf_terms.terms)].terms.values
        self.mask_terms_dgop = self.deepf_terms[self.deepf_terms.terms.isin(transfer_terms.terms)].terms.values
        self.label_permutation = [list(mask_terms_transfer).index(t) for t in self.mask_terms_dgop]
        #self.anti_mask = self.deepf_terms[~self.deepf_terms.terms.isin(self.mask_terms_dgop)].index.values
        self.mask = self.deepf_terms[self.deepf_terms.terms.isin(self.mask_terms_dgop)].index.values
        self.label_mask = transfer_terms[transfer_terms.terms.isin(self.mask_terms_dgop)].index.values[self.label_permutation]
        self.all_terms = self.deepf_terms.terms.values


    def __set_weights(self):
        weights = h5.File(self.config['model_file'])['model_weights']  
        self.fc1.weight = nn.Parameter(torch.FloatTensor(weights['dense/dense/kernel:0'][:]).permute(1,0))
        self.fc1.bias = nn.Parameter(torch.FloatTensor(weights['dense/dense/bias:0'][:]))

        self.fc2.weight = nn.Parameter(torch.FloatTensor(weights['labels/labels/dense_1/kernel:0'][:,::2]).permute(1,0))
        self.fc2.bias = nn.Parameter(torch.FloatTensor(weights['labels/labels/dense_1/bias:0'][::2]))

    def forward(self,x):
        z = self.fc1(x)
        z = self.activation(z)
        z = self.dropout(z)
        z = self.fc2(z)
        #out = self.sigmoid(z)
        out = self.softmax(z)
        #print(self.fc1.weight)
        return out

    def training_step(self,batch,batch_idx):
        x,y = batch
        y_hat = self.forward(x)
        loss = self.criterion(y_hat[:,self.mask],y[:,self.label_mask])
        self.log('train_loss',loss)
        return loss

    def validation_step(self,batch,batch_idx):
        x,y = batch
        y_hat = self.forward(x)
        loss = self.criterion(y_hat[:,self.mask],y[:,self.label_mask])
        self.log('val_loss',loss,on_epoch=True)

    def test_step(self,batch,batch_idx):
        x,y = batch
        y_hat = self.forward(x)
        return {'y_hat':y_hat,'y':y}
    
    def test_epoch_end(self, outputs):
        pass
        # y = torch.concat([x['y'] for x in outputs],dim=0).detach().cpu().numpy()
        # y_hat = torch.concat([x['y_hat'] for x in outputs],dim=0).detach().cpu().numpy()

        # y_hat_hier = update_scores(pd.DataFrame(data=y_hat,columns=self.deepf_terms.terms.values.flatten()), self.config['go_fn'])
        # performance_assessment(y_hat_hier.loc[:,self.mask_terms_dgop].values,y[:,self.label_mask])

    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(self.parameters(), lr=self.config['lr'],weight_decay=self.config['weight_decay'])
        print(self.config)
        lr_scheduler = LinearWarmupCosineAnnealingLR(optimizer, self.config_train['warm_up'], self.config_train['max_epochs'])
        return ([optimizer], [lr_scheduler])
        #return torch.optim.Adam(self.parameters(), lr=self.config['lr'],weight_decay=self.config['weight_decay'])

###########################
######  ORIGINAL    #######
###########################
class StructureNetwork_original(pl.LightningModule):
    def __init__(self,config,transfer_terms=None):
        super().__init__()
        self.config = config
        self.lm = LanguageModel(config)
        
        self.aa_embedding = nn.Linear(26,1024,bias=False)
        self.gcn1 = GCNLayer(config, 1, 512)
        self.gcn2 = GCNLayer(config, 2, 512)
        self.gcn3 = GCNLayer(config, 3, 512)
        self.fc1 = nn.Linear(3*512,1024)
        self.activation = eval(f"nn.{self.config['activation']}()")
        self.dropout = nn.Dropout(p=config['p'])
        self.fc2 = nn.Linear(1024,2*config['output_dim']) # Change this later for sigmoid!
        self.softmax = nn.Softmax(dim=-1)

        self.criterion = nn.CrossEntropyLoss()

        # Load the weights for transfer learning
        self.__set_weights()
        self.save_hyperparameters()

    def __set_weights(self):
        weights = h5.File(self.config['model_file'])['model_weights']
        self.aa_embedding.weight = nn.Parameter(torch.FloatTensor(weights['AA_embedding/AA_embedding/kernel:0'][:]).permute(1,0))
        for param in self.aa_embedding.parameters():
            param.requires_grad = False
        
        self.fc1.weight = nn.Parameter(torch.FloatTensor(weights['dense/dense/kernel:0'][:]).permute(1,0))
        self.fc1.bias = nn.Parameter(torch.FloatTensor(weights['dense/dense/bias:0'][:]))

        self.fc2.weight = nn.Parameter(torch.FloatTensor(weights['labels/labels/dense_1/kernel:0'][:]).permute(1,0))
        self.fc2.bias = nn.Parameter(torch.FloatTensor(weights['labels/labels/dense_1/bias:0'][:]))

    def forward(self,x):
        A,S = x
        s_1 = self.lm(S)
        s_2 = self.aa_embedding(S)
        s = self.activation(s_1 + s_2)
        a_1 = self.gcn1((A,s))
        a_2 = self.gcn2((A,a_1))
        a_3 = self.gcn3((A,a_2))
        z = torch.concat([a_1,a_2,a_3],dim=-1)
        z = torch.sum(z,axis=1)
        z = self.fc1(z)
        z = self.activation(z)
        z = self.dropout(z)
        z = self.fc2(z)
        z = z.reshape((z.shape[0],self.config['output_dim'],2))
        out = self.softmax(z)
        return out

    def training_step(self,batch,batch_idx):
        x,y = batch
        y_hat = self.forward(x)
        loss = self.criterion(y_hat[:,self.mask],y[:,self.label_mask])
        self.log('train_loss',loss)
        return loss

    def validation_step(self,batch,batch_idx):
        x,y = batch
        y_hat = self.forward(x)
        loss = self.criterion(y_hat[:,self.mask],y[:,self.label_mask])
        self.log('val_loss',loss,on_epoch=True)

    def test_step(self,batch,batch_idx):
        x,y = batch
        y_hat = self.forward(x)
        return {'y_hat':y_hat,'y':y}
    
    def test_epoch_end(self, outputs):
        y = torch.concat([x['y'] for x in outputs],dim=0).detach().cpu().numpy()
        y_hat = torch.concat([x['y_hat'] for x in outputs],dim=0).detach().cpu().numpy()

        y_hat_hier = update_scores(pd.DataFrame(data=y_hat,columns=self.deepf_terms.terms.values.flatten()), self.config['go_fn'])
        performance_assessment(y_hat_hier.loc[:,self.mask_terms_dgop].values,y[:,self.label_mask])

    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=self.config['lr'],weight_decay=self.config['weight_decay'])

class ExtractedStructureNetwork_original(pl.LightningModule):
    def __init__(self,config):
        super().__init__()
        self.config = config
        self.fc1 = nn.Linear(3*512,1024)
        self.activation = eval(f"nn.{self.config['activation']}()")
        self.dropout = nn.Dropout(p=config['p'])
        self.fc2 = nn.Linear(1024,2*config['output_dim'])
        self.softmax = nn.Softmax(dim=-1)

        self.__set_weights()


    def __set_weights(self):
        weights = h5.File(self.config['model_file'])['model_weights']  
        self.fc1.weight = nn.Parameter(torch.FloatTensor(weights['dense/dense/kernel:0'][:]).permute(1,0))
        self.fc1.bias = nn.Parameter(torch.FloatTensor(weights['dense/dense/bias:0'][:]))

        self.fc2.weight = nn.Parameter(torch.FloatTensor(weights['labels/labels/dense_1/kernel:0'][:]).permute(1,0))
        self.fc2.bias = nn.Parameter(torch.FloatTensor(weights['labels/labels/dense_1/bias:0'][:]))

    def forward(self,x):
        z = self.fc1(x)
        z = self.activation(z)
        z = self.dropout(z)
        z = self.fc2(z)
        z = z.reshape((z.shape[0],self.config['output_dim'],2))
        out = self.softmax(z)
        return out

###########################
### ADDITIONAL LAYERS #####
###########################
class LanguageModel(pl.LightningModule):
    def __init__(self,config):
        super().__init__()
        self.config = config
        self.lstm1 = nn.LSTM(input_size=26,hidden_size=512,batch_first=True)
        self.lstm2 = nn.LSTM(input_size=512,hidden_size=512,batch_first=True)
        self.embedding = nn.Linear(1024,1024)
        self.__set_weights()
    
    def __set_weights(self):
        weights = h5.File(self.config['model_file'])['model_weights']
        self.lstm1.weight_ih_l0 = nn.Parameter(torch.FloatTensor(weights['functional_1/LSTM1/lstm_cell/kernel:0'][:]).permute(1,0))
        self.lstm1.bias_ih_l0 = nn.Parameter(torch.FloatTensor(weights['functional_1/LSTM1/lstm_cell/bias:0'][:]))
        self.lstm1.weight_hh_l0 = nn.Parameter(torch.FloatTensor(weights['functional_1/LSTM1/lstm_cell/recurrent_kernel:0'][:]).permute(1,0))
        self.lstm1.bias_hh_l0 = nn.Parameter(torch.zeros(2048))
        for param in self.lstm1.parameters():
            param.requires_grad = False

        self.lstm2.weight_ih_l0 = nn.Parameter(torch.FloatTensor(weights['functional_1/LSTM2/lstm_cell_1/kernel:0'][:]).permute(1,0))
        self.lstm2.bias_ih_l0 = nn.Parameter(torch.FloatTensor(weights['functional_1/LSTM2/lstm_cell_1/bias:0'][:]))
        self.lstm2.weight_hh_l0 = nn.Parameter(torch.FloatTensor(weights['functional_1/LSTM2/lstm_cell_1/recurrent_kernel:0'][:]).permute(1,0))
        self.lstm2.bias_hh_l0 = nn.Parameter(torch.zeros(2048))
        for param in self.lstm2.parameters():
            param.requires_grad = False

        self.embedding.weight = nn.Parameter(torch.FloatTensor(weights['LM_embedding/LM_embedding/kernel:0'][:]).permute(1,0))
        self.embedding.bias = nn.Parameter(torch.FloatTensor(weights['LM_embedding/LM_embedding/bias:0'][:]))
        for param in self.embedding.parameters():
            param.requires_grad = False
    
    def forward(self,x):
        z1,_ = self.lstm1(x)
        z2,_ = self.lstm2(z1)
        z = torch.concat([z1,z2],dim=-1)
        z = self.embedding(z)
        return z

class GCNLayer(pl.LightningModule):
    """
         Graph Convolution Layer according to (T. Kipf and M. Welling, ICLR 2017)
         Reimplemented from DeepFRI in PyTorch for consistency.
         No bias or kernel regularizer as these layers are not trained
    """

    def __init__(self, config, layer_num, output_dim, activation='ELU'):
        super().__init__()
        self.config = config
        self.output_dim = output_dim
        self.activation = eval(f'nn.{activation}()')
        self.__set_weights(layer_num)

    def __set_weights(self,layer_num):
        weights = h5.File(self.config['model_file'])['model_weights']
        self.kernel = nn.Parameter(torch.FloatTensor(weights[f'GraphConv_{layer_num}/GraphConv_{layer_num}/kernel:0'][:]),requires_grad=False)

    def __normalize(self, A, eps=1e-6):
        n = A.shape[-1]
        A -= torch.diagonal(A,dim1=-2,dim2=-1)*torch.eye(n)
        A_hat = A + torch.eye(n)
        D_hat = (1./(eps + torch.sqrt(torch.sum(A_hat, axis=-1))))*torch.eye(n)
        return torch.matmul(torch.matmul(D_hat, A_hat), D_hat)

    def forward(self, x):
        A,S = x
        z = torch.matmul(self.__normalize(A),S)
        z = torch.matmul(z,self.kernel)
        if self.activation is not None:
            output = self.activation(z)
        return output

class FeatureExtractor(pl.LightningModule):
    '''
    Batched loading of the graphs and sequences is rather a nuissance.
    Since we are not training these layers anyway, we first extract vectorial features
    which we save.
    '''
    def __init__(self,config):
        super().__init__()
        self.config = config
        self.lm = LanguageModel(config)
        self.activation = eval(f"nn.{self.config['activation']}()")
        self.aa_embedding = nn.Linear(26,1024,bias=False)
        self.gcn1 = GCNLayer(config, 1, 512)
        self.gcn2 = GCNLayer(config, 2, 512)
        self.gcn3 = GCNLayer(config, 3, 512)
        # Load the weights for transfer learning
        self.__set_weights()
        self.save_hyperparameters()

    def __set_weights(self):
        weights = h5.File(self.config['model_file'])['model_weights']
        self.aa_embedding.weight = nn.Parameter(torch.FloatTensor(weights['AA_embedding/AA_embedding/kernel:0'][:]).permute(1,0))
        for param in self.aa_embedding.parameters():
            param.requires_grad = False

    def forward(self,x):
        A,S = x
        s_1 = self.lm(S)
        s_2 = self.aa_embedding(S)
        s = self.activation(s_1 + s_2)
        a_1 = self.gcn1((A,s))
        a_2 = self.gcn2((A,a_1))
        a_3 = self.gcn3((A,a_2))
        z = torch.concat([a_1,a_2,a_3],dim=-1)
        out = torch.sum(z,axis=1)
        return out 

