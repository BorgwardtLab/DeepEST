import os
from glob import glob

import pytorch_lightning as pl
import torch
from torch.utils.data import Dataset, DataLoader

import pandas as pd
import numpy as np

from src.utils import load_pickle
from IPython import embed

class StructureDataModule(pl.LightningDataModule):
    def __init__(self, config, proteins_path, matrix_label_path, conversion_dict, splits_dir, split=0):
        super().__init__()
        self.config = config
        self.data  = load_pickle(proteins_path)
        self.label = pd.read_csv(matrix_label_path)
        self.conversion_dict = pd.read_csv(conversion_dict, 
            names = ["New_locus_tag", "Protein_id", "No"], sep = " ")
        self.split = split
        self.splitdir = splits_dir 


    def setup(self, stage=None):
        train_idx,val_idx,test_idx = self._get_split_gene_names()

        self.train_set = ExtractedStructureDataset(self.config, self.data, 
            self.conversion_dict.loc[train_idx], self.label.loc[train_idx].values)
        self.val_set   = ExtractedStructureDataset(self.config, self.data, 
            self.conversion_dict.loc[val_idx], self.label.loc[val_idx].values)
        self.test_set  = ExtractedStructureDataset(self.config,  self.data, 
            self.conversion_dict.loc[test_idx], self.label.loc[test_idx].values)
    
    def _get_split_gene_names(self):
        train_idx = np.load(os.path.join(self.splitdir,f'train_index_{self.split}.npy'))
        val_idx   = np.load(os.path.join(self.splitdir,f'val_index_{self.split}.npy'))
        test_idx  = np.load(os.path.join(self.splitdir,f'test_index_{self.split}.npy'))

        return train_idx,val_idx,test_idx

    def train_dataloader(self):
        return DataLoader(self.train_set,batch_size=self.config['batch_size'],
                            num_workers=self.config['num_workers'],shuffle=False)
    def val_dataloader(self):
        return DataLoader(self.val_set,batch_size=self.config['batch_size'],
                            num_workers=self.config['num_workers'],shuffle=False)
    def test_dataloader(self):
        return DataLoader(self.test_set,batch_size=self.config['batch_size'],
                            num_workers=self.config['num_workers'],shuffle=False)

class ExtractedStructureDataset(Dataset):
    def __init__(self,config,sample,sample_conversion,label=None):
        super().__init__()
        self.sample = sample
        self.sample_conversion = sample_conversion
        if label is None:
            self.label = None
        else:
            self.label = label
        self.config = config
    def __getitem__(self,idx):
        protein_id = self.sample_conversion.iloc[idx]['Protein_id']
        features = torch.FloatTensor(self.sample[protein_id])

        if self.label is not None:
            label =  torch.FloatTensor(self.label[idx])
            return features,label
        else:
            return features

    def __len__(self):
        return len(self.sample_conversion)


### Old
class StructureDataset(Dataset):
    def __init__(self,config,sample_path,sample_conversion,label=None):
        super().__init__()
        # Remember "sample" here is a list of files, not a dataframe!
        self.sample_path = sample_path
        self.sample_conversion = sample_conversion
        if label is None:
            self.label = None
        else:
            self.label = label
        self.config = config
    def __getitem__(self,idx):
        label =  torch.FloatTensor(self.label[idx])
        protein_id = self.sample_conversion.iloc[idx]['Protein_id']

        structure,sequence = load_predicted_PDB(os.path.join(self.sample_path,f'{protein_id}.pdb'))

        cmap = torch.FloatTensor((structure < self.config['cmap_thresh']))
        one_hot = torch.FloatTensor(seq2onehot(sequence))

        return (cmap,sequence),label

    def __len__(self):
        return len(self.sample_conversion)