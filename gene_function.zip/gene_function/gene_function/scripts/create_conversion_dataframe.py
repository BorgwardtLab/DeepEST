import numpy as np
import pandas as pd
from glob import glob
from tqdm import tqdm
import os

def filter_species(inp,exclusion_list):
    for e in exclusion_list:
        inp = [l for l in inp if e not in l]
    return inp

all_genes_files = sorted(glob('../data/processed_files/splits/*/genes.npy'))

all_go = sorted(glob('../output/GOTerms/*_GO_terms.csv'))
all_accessions = sorted(glob('../output/GOTerms/*_accession.csv'))
all_expr = sorted(glob('../data/Gene expression and DEG files/*.csv'))

exclusion_list = ['Aggregatibacter', 'Enterococcus','Streptococcus suis','Streptococcus_suis',\
                  'Acinetobacter','Francisella','Neisseria_meningitidis','Neisseria meningitidis',\
                  'Yersinia', 'all_species']
all_genes_files = filter_species(all_genes_files,exclusion_list)
all_go = filter_species(all_go,exclusion_list)
all_accessions = filter_species(all_accessions,exclusion_list)
all_expr = filter_species(all_expr,exclusion_list)

# print([len(l) for l in [all_genes_files,all_go,all_expr,all_accessions]])

for l,g,e,a in zip(all_genes_files,all_go,all_expr,all_accessions):
    species_name = '_'.join(a.split('/')[-1].split('_')[:-1])
    if not os.path.exists(f'../data/processed_files/conversion_dicts/{species_name}_dict.csv'):
        print(species_name)
        labels = np.load(l)
        gos = pd.read_csv(g,index_col=0)
        expr = pd.read_csv(e,index_col=0,sep=';',low_memory=False)
        acc = pd.read_csv(a)

        ids = gos.loc[labels,['Protein_id']]['Protein_id']
        all_identifiers = expr[expr['Protein_id'].isin(ids.values)].loc[:,['Protein_id','Old_locus_tag','New_locus_tag']]

        missing_new_tag = all_identifiers[all_identifiers['New_locus_tag'].isna()].index
        all_identifiers.loc[missing_new_tag,'New_locus_tag'] = all_identifiers.loc[missing_new_tag,'Old_locus_tag'].values

        missing_old_tag = all_identifiers[all_identifiers['Old_locus_tag'].isna()].index
        all_identifiers.loc[missing_old_tag,'Old_locus_tag'] = all_identifiers.loc[missing_old_tag,'New_locus_tag'].values


        relevant_acc = acc[acc.Protein_id.isin(all_identifiers.Protein_id.values)].loc[:,['Protein_id','accession']].drop_duplicates()
        for i in all_identifiers.index:
            all_identifiers.loc[i,'Uniprot'] = relevant_acc[relevant_acc.Protein_id==all_identifiers.loc[i,'Protein_id']].accession.item()

        all_identifiers.to_csv(f'../data/processed_files/conversion_dicts/{species_name}_dict.csv',index=False)