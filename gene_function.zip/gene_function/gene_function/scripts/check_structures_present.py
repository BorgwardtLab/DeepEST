import os
from glob import glob, iglob
import pandas as pd
import numpy as np
from tqdm import tqdm

from IPython import embed

all_id_files = glob('data/processed_files/features/*_genomic_info.csv')
all_ids = []

for f in all_id_files:
    df = pd.read_csv(f)
    try:
        all_ids.extend(df.Protein_id.values.tolist())
    except:
        print(f)

print(len(all_ids))

all_structures = glob('data/processed_files/structure/*/*.pdb')

print(len(all_structures))

all_ids_structure = [s.split('/')[-1][:-4] for s in all_structures]

missing = []

for i in all_ids:
    if not i in all_ids_structure:
        missing.append(i)

np.savetxt('data/processed_files/structure/missing_structures.txt',np.array(missing),delimiter="\n", fmt="%s")
print(len(missing))