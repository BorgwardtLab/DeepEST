import pytorch_lightning as pl
import torch

import os
import yaml
import time
import argparse

import numpy as np
import pandas as pd
from tqdm import tqdm

from src.utils import fasta_to_df

from src.structure_datamodule import StructureDataModule, StructureDataset
from src.structure_model import ExtractedStructureNetwork_masked

def parse_arguments():
    '''
    Definition of the command line arguments
    '''
    parser = argparse.ArgumentParser()
    parser.add_argument('--species', required = True, help = 'species')
    parser.add_argument('--matrix_label_path', required = True, help = 'matrix of the labels')
    parser.add_argument('--protein_path', required = True, help = 'file containing the pickled extracted features')
    parser.add_argument('--split', required = True, type=int, help = 'which split to use')
    parser.add_argument('--split_dir', required = True, help = 'directory of the split')
    parser.add_argument('--conversion_dict', required = True, help = 'conversion dictionaries')
    parser.add_argument('--outdir', required = True, help = 'output directory')
    args = parser.parse_args()
    return args

def save_preds(model,datamodule,outdir='output',out_name='GCN_val_preds',mode='val'):
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model.eval() # freezing the weights
    term_names = model.all_terms
    if mode=='train':
        gene_names,_,_ = datamodule._get_split_gene_names()
    elif mode=='val':
        _,gene_names,_ = datamodule._get_split_gene_names()
    elif mode=='test':
        _,_,gene_names = datamodule._get_split_gene_names()
    else:
        raise ValueError('"mode" needs to be either "train", "val", or "test"!')
    gene_names = datamodule.conversion_dict.loc[gene_names,'New_locus_tag']
    y_hat_list = []
    for x,_ in tqdm(eval(f'datamodule.{mode}_dataloader()'),leave=False,desc=f'Saving {mode} predictions'):
        y_hat_list.append(model.forward(x.to(device)).detach().cpu().numpy())
    y_hat = np.vstack(y_hat_list)
    y_hat_df = pd.DataFrame(y_hat,index=gene_names,columns=term_names)
    y_hat_df.to_csv(os.path.join(outdir,out_name+'.csv'),index=True)
    model.train() # unfreezing the weights


if __name__ == '__main__':
    # Seed everything
    pl.seed_everything(47, workers=True)

    # Load config
    with open('src/config_deepfri.yaml','r') as f:
        config = yaml.safe_load(f)

    # Parse args
    args = parse_arguments()

    
    # Load data
    data = StructureDataModule(config['data_params'], args.protein_path,
                               args.matrix_label_path, args.conversion_dict,
                               args.split_dir, split=args.split)
    data.setup()

    # Find the GO terms for the species in question
    transfer_terms = pd.DataFrame(data.label.columns.values,columns=['terms'])

    # Load model
    model = ExtractedStructureNetwork_masked(config['model_params'],
                                         config["training_params"],transfer_terms)


    # Checkpoint callback
    checkpoint_callback = pl.callbacks.ModelCheckpoint(dirpath='src/trained_models/{}/deepFRI'.format(args.split_dir),
                                                    filename= f"{args.species.replace(' ','_')}_split_{args.split}",
                                                    monitor='val_loss',
                                                    mode='min',
                                                    save_top_k=1,
                                                    every_n_epochs=10,
                                                    verbose=True)
    
    # Early stopping callback
    early_stopping_callback = pl.callbacks.EarlyStopping(monitor='val_loss',
                                                        mode='min',
                                                        min_delta = 0.0,
                                                        patience = 4)


    # Trainer
    trainer = pl.Trainer(max_epochs=config['training_params']['max_epochs'],
                        enable_progress_bar=True,
                        callbacks=[checkpoint_callback,early_stopping_callback],
                        logger=None,#wandb_logger,
                        log_every_n_steps=1,
                        check_val_every_n_epoch = 5,
                        accelerator='gpu' if torch.cuda.is_available() else 'cpu',
                        devices=1, #if torch.cuda.is_available() else None,
                        deterministic=True)

    
    model = model.to('cuda' if torch.cuda.is_available() else 'cpu')
    save_preds(model,data,outdir='{}/{}'.format(args.outdir, args.species.replace(' ','_')),
         out_name=f"{args.species.replace(' ','_')}_val_preds_no_transfer_deepfri_split_{args.split}",mode='val')
    save_preds(model,data,outdir='{}/{}'.format(args.outdir, args.species.replace(' ','_')),
        out_name=f"{args.species.replace(' ','_')}_test_preds_no_transfer_deepfri_split_{args.split}",mode='test')

    # Fit
    print(f"Training started at {time.asctime(time.localtime(time.time()))}.") 
    trainer.fit(model,datamodule=data)
    print(f"Training finished at {time.asctime(time.localtime(time.time()))}.") 

    # Uncomment if you want to test here.
    trainer.test(datamodule=data,ckpt_path='best')
    model = model.to('cuda' if torch.cuda.is_available() else 'cpu')
    save_preds(model,data,outdir='{}/{}'.format(args.outdir, args.species.replace(' ','_')),
        out_name=f"{args.species.replace(' ','_')}_val_preds_transfer_deepfri_split_{args.split}",mode='val')
    save_preds(model,data,outdir='{}/{}'.format(args.outdir, args.species.replace(' ','_')),
        out_name=f"{args.species.replace(' ','_')}_test_preds_transfer_deepfri_split_{args.split}",mode='test')

