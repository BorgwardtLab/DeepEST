import pickle
from glob import glob

all_files = glob('data/processed_files/extracted_features/*.pkl')
all_files = [f for f in all_files if not 'all_proteins' in f]
out_dict = {}

for file in all_files:
    with open(file,'rb') as f:
        d = pickle.load(f)
    out_dict.update(d)

with open('data/processed_files/extracted_features/all_proteins.pkl','wb') as f:
    pickle.dump(out_dict,f)