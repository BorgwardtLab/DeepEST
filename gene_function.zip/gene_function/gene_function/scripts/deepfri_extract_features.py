import pytorch_lightning as pl
import torch
#from torchinfo import summary

import os
import yaml
import time
import argparse
import pickle
from glob import glob
from tqdm import tqdm

import numpy as np
import pandas as pd

from multiprocessing import cpu_count
from joblib import Parallel, delayed

from IPython import embed

import sys
sys.path.insert(1, '../../')


from src.structure_model import FeatureExtractor
from src.utils_deepfri import load_predicted_PDB, seq2onehot


def extract_features(args,model,folder):
    files = glob(os.path.join(folder,'*.pdb'))
    out_name = '_'.join(folder.split('/')[-1].split(' '))
    out_file = os.path.join(args.out_dir,f'{out_name}.pkl')
    out_dict = {}
    if not os.path.exists(out_file):
        for pdb in tqdm(files,desc=out_name,leave=False,disable=True):
            prot_id = pdb.split('/')[-1][:-4]
            A,S = load_predicted_PDB(pdb)
            A = torch.FloatTensor(A < 10.0).unsqueeze(0).to(device)
            S = torch.FloatTensor(seq2onehot(S)).unsqueeze(0).to(device)
            
            with torch.no_grad():
                out = model((A,S)).squeeze().detach().cpu().numpy()
            
            out_dict[prot_id] = out
        with open(out_file,'wb') as f:
            pickle.dump(out_dict, f)

def parse_arguments():
    '''
    Definition of the command line arguments
    '''
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', required = True, help = 'The base directory of all structure data')
    parser.add_argument('--out_dir', required = True, help = 'The base ouput directory for the pickled files')
    args = parser.parse_args()
    return args

if __name__ == '__main__':
    # Select device
    device = 'cpu' #'cuda' if torch.cuda.is_available() else 'cpu'

    # Seed everything
    pl.seed_everything(47, workers=True)

    # Load config
    with open('src/config_deepfri.yaml','r') as f:
        config = yaml.safe_load(f)

    # Parse args
    args = parse_arguments()

    # Load model
    model = FeatureExtractor(config['model_params']).to(device)
    model.eval()
    #summary(model)

    extract_features(args,model,args.data_dir)

    #Parallel(n_jobs=cpu_count(),verbose=10)(delayed(extract_features)(args,model,folder) for folder in folders)

    # for folder in folders:
    #     files = glob(os.path.join(folder,'*.pdb'))
    #     out_name = '_'.join(folder.split('/')[-1].split(' '))
    #     out_file = os.path.join(args.out_dir,f'{out_name}.pkl')
    #     out_dict = {}
    #     if not os.path.exists(out_file):
    #         for pdb in tqdm(files,desc=out_name,leave=False):
    #             prot_id = pdb.split('/')[-1][:-4]
    #             A,S = load_predicted_PDB(pdb)
    #             A = torch.FloatTensor(A < 10.0).unsqueeze(0).to(device)
    #             S = torch.FloatTensor(seq2onehot(S)).unsqueeze(0).to(device)

    #             with torch.no_grad():
    #                 out = model((A,S)).squeeze().detach().cpu().numpy()
                
    #             out_dict[prot_id] = out
    #         with open(out_file,'wb') as f:
    #             pickle.dump(out_dict, f)

