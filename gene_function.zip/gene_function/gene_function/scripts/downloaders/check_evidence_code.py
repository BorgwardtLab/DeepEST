
import sys
import json
import argparse
import requests

import numpy as np
import pandas as pd

from IPython import embed
from tqdm import tqdm
#import biomart


def main():
  species = get_species()
  STRING = ""
  counts = init_res()
  for s in species:
    STRING += "{}\n".format(s)
    filename = '/home/gmuzio/running_baselines_regression/data/GOTerms_new/{}_annotations.csv'.format(s)
    res = pd.read_csv(filename, sep = "\t")
    STRING, COUNTS = check_evidence(res, s, STRING, counts)
    STRING += "--------\n"
  print(STRING)
  with open("evidence_codes.txt", "w") as f:
    f.write(STRING)
    f.write("\n\n\n")
    f.write("CODE\tCOUNTS\tPERCENTAGE\n")
    for ev, c in zip(COUNTS.keys(), COUNTS.values()):
      perc = np.round(100*c/COUNTS["tot"], 2)
      f.write("{}\t{}\t{}\n".format(ev, c, perc)) 
      # these percentages that we are writing are for the annotations,
      # so they are way more than the number of genes and the number of 
      # go terms. They're basically the number of 1s in the label matrix.



def check_evidence(res, s, STRING, COUNTS):
  evidences = res.Evidence
  evs, counts = np.unique(evidences, return_counts = True)
  for e, c in zip(evs, counts):
    perc = np.round(c/len(evidences)*100, 2)
    STRING += "{}\t{}\n".format(e, perc)
    COUNTS[e]+=c
    COUNTS["tot"]+=c

  return STRING, COUNTS


def init_res():
  return {'EXP':0, "IBA":0, "IDA":0, "IEA": 0, "IEP":0, "IGC":0, "IGI":0, 
  "IMP":0, "ISS":0, "NAS":0, "TAS":0, "IPI":0, "tot":0}



def get_species():
  return ['Achromobacter_xylosoxidans_SOLR10',
          'Escherichia_coli_ETEC_H10407',
          'Helicobacter_pylori_G27',
          'Pseudomonas_aeruginosa_PAO1',
          'Staphylococcus_aureus_MSSA476',
          'Borrelia_burgdorferi_B31',
          'Burkholderia_pseudomallei_K96243',
          'Campylobacter_jejuni_subsp._jejuni_81-176',
          'Escherichia_coli_EPEC_0127_H6_E2348_69',
          'Escherichia_coli_UPEC_536',
          'Haemophilus_influenzae_86-028NP',
          'Helicobacter_pylori_J99',
          'Klebsiella_pneumoniae_subsp._pneumoniae_MGH_78578',
          'Legionella_pneumophila_subsp._pneumophila_Philadelphia_1',
          'Listeria_monocytogenes_EGD-e',
          'Mycobacterium_tuberculosis_H37Ra',
          'Neisseria_gonorrhoeae_FA_1090',
          'Salmonella_enterica_subsp._enterica_serovar_TyphimuriumSL1344',
          'Shigella_flexneri_5a_str._M90T_new',
          'Staphylococcus_aureus_MRSA252',
          'Staphylococcus_epidermidis_1457',
          'Streptococcus_agalactiae_NEM316',
          'Streptococcus_pneumoniae_D39',
          'Streptococcus_pyogenes_5448',
          'Vibrio_cholerae_O1_biovar_El_Tor_str._N16961']


if __name__ == '__main__':
  main()

