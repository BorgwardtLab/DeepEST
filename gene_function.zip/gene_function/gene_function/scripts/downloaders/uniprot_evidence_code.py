import urllib.parse
import urllib.request
from urllib.error import URLError
from http.client import RemoteDisconnected
import os
import re
import pandas as pd
import numpy as np
from time import sleep
from tqdm import tqdm
from joblib import Parallel,delayed
from multiprocessing import cpu_count
from IPython import embed
import requests
import json
import argparse

DATA_PATH = '/home/gmuzio/running_baselines_regression/data/OneDrive_1_2-1-2022/' 
CSV_PATH = os.path.join(DATA_PATH,'Gene expression and DEG files')
MAX_NUMBER = 10

def get_protein_ids(file_name):
    data_df = pd.read_csv(os.path.join(CSV_PATH,file_name),sep=';',index_col=0)
    all_genes_df = pd.read_csv(os.path.join(DATA_PATH,'PGFAMs_for_genes.csv'),sep=',',index_col=0) #On my Macbook that's a comma!

    patric_ids = all_genes_df.loc[all_genes_df.index.isin(data_df.index),['ref_genome_patric_id']]

    protein_ids = pd.concat([data_df.loc[:,['Protein_id','Old_locus_tag']],patric_ids],axis=1)
    return protein_ids


def request_id(p,columns,taxon):
    # Example call:
    # https://rest.uniprot.org/uniprotkb/search?from=P_REFSEQ_AC&to=ACC&query=WP_000130189.1%20AND%20taxonomy_id:316401&fields=accession,go,go_p,
    url = 'https://rest.uniprot.org/uniprotkb/search'
    params={
    'from': 'P_REFSEQ_AC',
    'to':'ACC',
    'fields':columns,
    'query':p,#'WP_001264699.1,WP_000241648.1',
    'taxonomy_id': taxon,
    }

    
    req = url+ f"?from={params['from']}&to={params['to']}&query={params['query']}%20AND%20taxonomy_id:{params['taxonomy_id']}&fields={params['fields']}"
    r = requests.get(req)
    results = r.json()["results"]
    
    results_string = ""
    if ( len(results) > 0):
        annotations = results[0]["uniProtKBCrossReferences"]
        for a in annotations:
            category = a["properties"][0]["value"]
            if("P:" in category):
                single_go = "{}\t{}\t{}\n".format(p, a["id"], a["properties"][1]["value"].split(":")[0])
                results_string += single_go
    if (len(results_string) > 0):
        return results_string



def main(args):
    idx = args.species

    df_species_tax = pd.read_csv(os.path.join('../..','data','taxonomies_completed.csv'),index_col = 0)  
    taxon = df_species_tax.loc[idx,'taxonomy']
    if (idx=='Shigella flexneri 5a str. M90T'):
        idx += "_new"
        
    print(f"Species: {idx}")
    file_name = idx + '.csv'
    file_name_out = idx.replace(' ','_') + '_annotations.csv'
    out_file = os.path.join('/home/gmuzio/running_baselines_regression/data/GOTerms_new/',
        file_name_out)

    columns = 'go'
    protein_ids = get_protein_ids(file_name)

    identifiers = protein_ids['Protein_id'].dropna().tolist()

    res_str = ""
    for p in tqdm(identifiers):
        res = request_id(p,columns,taxon)
        if(res):
            res_str += res

    with open(out_file,'w') as f:
        f.write("Protein_id\tGO_term\tEvidence\n")
        f.write(res_str)


def get_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('--species', required = True)
    args = parser.parse_args()
    return args
    

if __name__=='__main__':
    arguments = get_arguments()
    main(arguments)


