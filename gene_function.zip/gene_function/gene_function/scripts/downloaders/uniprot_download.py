import urllib.parse
import urllib.request
from urllib.error import URLError
from http.client import RemoteDisconnected
import os
import re
import pandas as pd
import numpy as np
from time import sleep
from tqdm import tqdm
from joblib import Parallel,delayed
from multiprocessing import cpu_count
from IPython import embed

DATA_PATH = '/home/gmuzio/running_baselines_regression/data/OneDrive_1_2-1-2022/' 
CSV_PATH = os.path.join(DATA_PATH,'Gene expression and DEG files')
MAX_NUMBER = 10

def get_protein_ids(file_name):
    data_df = pd.read_csv(os.path.join(CSV_PATH,file_name),sep=';',index_col=0)
    all_genes_df = pd.read_csv(os.path.join(DATA_PATH,'PGFAMs_for_genes.csv'),sep=',',index_col=0) #On my Macbook that's a comma!

    patric_ids = all_genes_df.loc[all_genes_df.index.isin(data_df.index),['ref_genome_patric_id']]

    protein_ids = pd.concat([data_df.loc[:,['Protein_id','Old_locus_tag']],patric_ids],axis=1)
    return protein_ids


def get_go_terms_prot_id(out_file,columns,protein_ids,taxon):
    if not os.path.isfile(out_file+'_Protein_id.csv'):
        responses = Parallel(n_jobs=2*cpu_count(),verbose=1)(delayed(downloader_id)(p,columns,taxon) for p in protein_ids)
        responses = ''.join(responses)

        with open(out_file+'_Protein_id.csv','w') as f:
            f.write(columns.replace(',','\t')+'\tprotein_id'+'\tsuccess_tag'+'\n')
            f.write(responses)


def downloader_id(p,columns,taxon):
    # Example call:
    # https://rest.uniprot.org/uniprotkb/search?from=P_REFSEQ_AC&to=ACC&query=WP_000130189.1%20AND%20taxonomy_id:316401&format=tsv&fields=accession,go,go_p
    url = 'https://rest.uniprot.org/uniprotkb/search'
    params={
    'from': 'P_REFSEQ_AC',
    'to':'ACC',
    'format':'tsv',
    'fields':columns,
    'query':p,#'WP_001264699.1,WP_000241648.1',
    'taxonomy_id': taxon,
    }

    error_dict={URLError:'URLError',RemoteDisconnected:'RemoteDisconnected'}

    try:
        req = url+ f"?from={params['from']}&to={params['to']}&query={params['query']}%20AND%20taxonomy_id:{params['taxonomy_id']}&format={params['format']}&fields={params['fields']}"
        # data = urllib.parse.urlencode(params)
        # data = data.encode('utf-8')
        # req = urllib.request.Request(url, data)
        with urllib.request.urlopen(req) as f:
           response = f.read().decode('utf-8')
        response = response.split('\n')[:-1]
        if len(response)>1:
            response = response[1] + f"\t{params['query']}\tsuccess\n"
            return response
        else:
            return '\t'.join(len(columns.split(','))*[''] + [p,'success']) + '\n'
    except (URLError,RemoteDisconnected) as error:
        return '\t'.join(len(columns.split(','))*[''] + [p,error_dict[type(error).__name__]]) + '\n'


def merge_to_df(ids,protein_ids,out_file):
    df = pd.read_csv(out_file+'_'+ids+'.csv',index_col=-2,sep='\t')
    go_terms = df['go_p']
    go_terms_list = go_terms.tolist()
    go_terms_idx = go_terms.index.tolist()
    for idx,go in zip(go_terms_idx,go_terms_list):
        valid_ids = protein_ids[protein_ids[ids] == idx].index.values
        if not pd.isna(go):
            protein_ids.loc[valid_ids,[f'target_go_{ids}']] = ','.join(re.findall('\[(.*?)\]',go))
            protein_ids.loc[valid_ids,[f'annotation_score_{ids}',f'reviewed_{ids}',f'success_tag_{ids}']] = df.loc[idx,['annotation_score','reviewed','success_tag']].values
            # df.loc[idx,['target_go']] = ','.join(re.findall('\[(.*?)\]',go))
        else:
            protein_ids.loc[valid_ids,[f'success_tag_{ids}']] = df.loc[idx,['success_tag']].values
            protein_ids.loc[valid_ids,[f'target_go_{ids}']] = np.nan
            protein_ids.loc[valid_ids,[f'annotation_score_{ids}',f'reviewed_{ids}']] = np.nan
            # df.loc[idx,['target_go']] = np.nan
    return protein_ids


def main():

    df_species_tax = pd.read_csv(os.path.join('../..','data','taxonomies_completed.csv'),index_col = 0)
    for idx in df_species_tax.index:
        taxon = df_species_tax.loc[idx,'taxonomy']

        if (idx=='Shigella flexneri 5a str. M90T'):
            idx += "_new"
            
        print(f"Species: {idx}")
        file_name = idx + '.csv'
        file_name_out = idx.replace(' ','_') + '_GO_terms.csv'
        out_file = os.path.join('/home/gmuzio/running_baselines_regression/data/GOTerms_new/',file_name_out)

        file_name_out_int = idx.replace(' ','_')
        out_file_int = os.path.join('/home/gmuzio/running_baselines_regression/data/GOTerms_new/',file_name_out_int)
        
        columns = 'accession,go,go_p,go_id,annotation_score,reviewed'
        protein_ids = get_protein_ids(file_name)

        if not os.path.isfile(out_file):
            # for ids,func in zip(['Protein_id','Old_locus_tag','ref_genome_patric_id'],[get_go_terms_prot_id,get_go_terms_locus_tag,get_go_terms_patric]):
            #     print(ids)
            #     identifiers = protein_ids[ids].dropna().tolist()
            #     func(out_file_int,columns,identifiers,taxon)
            #     protein_ids = merge_to_df(ids,protein_ids,out_file_int)
            identifiers = protein_ids['Protein_id'].dropna().tolist()
            get_go_terms_prot_id(out_file_int,columns,identifiers,taxon)
            protein_ids = merge_to_df('Protein_id',protein_ids,out_file_int)
            protein_ids.to_csv(out_file)



if __name__=='__main__':
    main()
