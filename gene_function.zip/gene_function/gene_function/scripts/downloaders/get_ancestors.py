import pandas as pd
import os
import re
import json
import itertools
import pandas as pd
import numpy as np
from time import sleep
from tqdm import tqdm
from joblib import Parallel,delayed
from multiprocessing import cpu_count
from IPython import embed

import requests
import sys

DATA_PATH = "/home/gmuzio/running_baselines_regression/data/GOTerms_new/"
NUM_TRY = 10

def get_target_terms(file_path):
    
    df_in = pd.read_csv(file_path,index_col=0)
    df_out = pd.DataFrame(index=df_in.index)

    for id in tqdm(df_in.index):
        gos_protein_id = set(df_in.loc[id,['target_go_Protein_id']].astype(str).values[0].split(','))
        # gos_locus_tag = set(df_in.loc[id,['target_go_Old_locus_tag']].astype(str).values[0].split(','))
        # gos_patric = set(df_in.loc[id,['target_go_ref_genome_patric_id']].astype(str).values[0].split(','))

        # target_gos = (gos_protein_id.union(gos_locus_tag).union(gos_patric))
        target_gos = gos_protein_id

        # remove NaNs
        target_gos = target_gos - set(['nan'])

        target_gos = list(target_gos)
        for go_id in range(len(target_gos)):
            df_out.loc[id,[f'GO_{go_id}']] = target_gos[go_id]

    return df_out

def request_ancestors(df):
    df_go_only = df.dropna(how='all')
    out = Parallel(n_jobs=2*cpu_count(),verbose=1)(delayed(downloader)(row_idx,df.loc[row_idx]) for row_idx in df_go_only.index)

    out_dfs = []
    obsolete_terms = []
    for t in out:
        out_dfs.append(t[0])
        obsolete_terms.append(t[1])
    try:
        return pd.concat(out_dfs),list(set(list(itertools.chain(*obsolete_terms))))
    except ValueError:
        print('No GO terms!')
        return pd.DataFrame(data=[]),list(set(list(itertools.chain(*obsolete_terms))))

def downloader(row_idx,row):
    row_df_list = []
    obsolete_terms = []
    for i,column in enumerate(row):
        if str(column) != 'nan':
            requestURL = f'https://www.ebi.ac.uk/QuickGO/services/ontology/go/terms/{column}/ancestors?relations=is_a'
            r = requests.get(requestURL, headers={ "Accept" : "application/json"})
            r_dict = json.loads(r.text)
            if r.ok:
                ancestor_dict = None
                if 'results' in r_dict.keys():
                    # Some GO terms are obsolete according to QuickGO. What does that mean??
                    if 'isObsolete' in r_dict['results'][0].keys():
                        if r_dict['results'][0]['isObsolete'] == True:
                            obsolete_terms.append(column)
                        else:
                            if 'ancestors' in r_dict['results'][0].keys():
                                ancestors = r_dict['results'][0]['ancestors']
                                ancestor_dict = {f'ancestor_{j}_of_term_{i}':ancestors[j] for j in range(len(ancestors))}
                    else:
                        if 'ancestors' in r_dict['results'][0].keys():
                            ancestors = r_dict['results'][0]['ancestors']
                            ancestor_dict = {f'ancestor_{j}_of_term_{i}':ancestors[j] for j in range(len(ancestors))}
                if ancestor_dict is not None:
                    row_df_list.append(pd.DataFrame(ancestor_dict,index=[row_idx]))
                #  catch terms which are not in QuickGO any more:
            else:
                obsolete_terms.append(column)
    if row_df_list != []:
        return pd.concat(row_df_list,axis=1),obsolete_terms
    else:
        return None,obsolete_terms


def main():
    df_species_tax = pd.read_csv(os.path.join('../..','data','taxonomies_completed.csv'),index_col = 0)
    for idx in df_species_tax.index:
    
        if (idx=='Shigella flexneri 5a str. M90T'):
            idx += "_new"
        print(f"Species: {idx}")
        if not os.path.exists(os.path.join(DATA_PATH,idx.replace(' ','_') + '_GO_terms' + '_with_ancestors.csv')):
            file_name = idx.replace(' ','_') + '_GO_terms.csv'
            file_path = os.path.join(DATA_PATH,file_name)

            df = get_target_terms(file_path)
            ancestors_df, obsolete_terms = request_ancestors(df)

            # remove obsolete_terms
            # I am assuming that if the terms is obsolete, then we won't need the term or its possible ancestors
            df[df.isin(obsolete_terms)] = np.nan

            out_df = pd.concat([df,ancestors_df],axis=1)
            out_df.to_csv(os.path.join(DATA_PATH,idx.replace(' ','_') + '_GO_terms' + '_with_ancestors.csv'))

if __name__=='__main__':
    main()
