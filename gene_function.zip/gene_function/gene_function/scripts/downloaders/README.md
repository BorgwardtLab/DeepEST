# Intro

This folder contains little scripts to download various stuff from Uniprot, QuickGO and AlphaFold.

It should be self-evident.