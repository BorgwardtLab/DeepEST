#!/bin/bash

for SPECIES in "Achromobacter xylosoxidans SOLR10" "Escherichia coli ETEC H10407" "Helicobacter pylori G27" "Pseudomonas aeruginosa PAO1" "Staphylococcus aureus MSSA476" "Borrelia burgdorferi B31" "Burkholderia pseudomallei K96243" "Campylobacter jejuni subsp. jejuni 81-176" "Escherichia coli EPEC 0127 H6 E2348 69" "Escherichia coli UPEC 536" "Haemophilus influenzae 86-028NP" "Helicobacter pylori J99" "Klebsiella pneumoniae subsp. pneumoniae MGH 78578" "Legionella pneumophila subsp. pneumophila Philadelphia 1" "Listeria monocytogenes EGD-e" "Mycobacterium tuberculosis H37Ra" "Neisseria gonorrhoeae FA 1090" "Salmonella enterica subsp. enterica serovar TyphimuriumSL1344" "Shigella flexneri 5a str. M90T" "Staphylococcus aureus MRSA252" "Staphylococcus epidermidis 1457" "Streptococcus agalactiae NEM316" "Streptococcus pneumoniae D39" "Streptococcus pyogenes 5448" "Vibrio cholerae O1 biovar El Tor str. N16961"; do

    python3 check_evidence_code.py --species "$SPECIES"

done