# %%
from glob import glob
import os
import urllib.parse
import urllib.request
from urllib.error import URLError,HTTPError
from http.client import RemoteDisconnected
from joblib import Parallel,delayed
from multiprocessing import cpu_count
import pandas as pd
import numpy as np
from tqdm import tqdm
from IPython import embed

# %%
CSV_PATH = '/home/gmuzio/running_baselines_regression/data/GOTerms_new'
OUT_PATH = '/home/gmuzio/running_baselines_regression/data/processed_files/structure'

def get_species():
    # SPECIES = ['Achromobacter_xylosoxidans_SOLR10', 'Borrelia_burgdorferi_B31', 'Burkholderia_pseudomallei_K96243', \
    #         'Campylobacter_jejuni_subsp._jejuni_81-176', 'Escherichia_coli_EPEC_0127_H6_E2348_69', 'Escherichia_coli_ETEC_H10407', \
    #         'Escherichia_coli_UPEC_536', 'Haemophilus_influenzae_86-028NP', 'Helicobacter_pylori_G27', \
    #         'Helicobacter_pylori_J99', 'Klebsiella_pneumoniae_subsp._pneumoniae_MGH_78578', \
    #         'Legionella_pneumophila_subsp._pneumophila_Philadelphia_1', 'Listeria_monocytogenes_EGD-e', \
    #         'Mycobacterium_tuberculosis_H37Ra', 'Neisseria_gonorrhoeae_FA_1090','Pseudomonas_aeruginosa_PAO1', \
    #         'Salmonella_enterica_subsp._enterica_serovar_TyphimuriumSL1344',
    return ['Shigella_flexneri_5a_str._M90T_new', \
            'Staphylococcus_aureus_MRSA252', 'Staphylococcus_aureus_MSSA476', 'Staphylococcus_epidermidis_1457', \
            'Streptococcus_agalactiae_NEM316', 'Streptococcus_pneumoniae_D39', 'Streptococcus_pyogenes_5448', \
            'Vibrio_cholerae_O1_biovar_El_Tor_str._N16961']
    


if __name__ =="__main__":
    
    SPECIES = get_species()
    for species_name in SPECIES:
        
        print(f"Species: {species_name}")

        if (not os.path.exists('{}/{}'.format(OUT_PATH, species_name) )):
            os.mkdir('{}/{}'.format(OUT_PATH, species_name))

        file = "{}/{}_Protein_id.csv".format(CSV_PATH, species_name)

        df = pd.read_csv(file, sep="\t")
        accs = df.accession.dropna().values

        error_dict={URLError:'URLError',RemoteDisconnected:'RemoteDisconnected',HTTPError:'HTTPError'}

        not_found = []


        for acc in tqdm(accs):
            if not os.path.exists(os.path.join(OUT_PATH,species_name,df[df.accession==acc].protein_id.values[0]+'.pdb')):
                try:
                    req = f'https://alphafold.ebi.ac.uk/files/AF-{acc}-F1-model_v4.pdb'
                    # data = urllib.parse.urlencode(params)
                    # data = data.encode('utf-8')
                    # req = urllib.request.Request(url, data)
                    with urllib.request.urlopen(req) as f:
                        response = f.read().decode('utf-8')
                        with open(os.path.join(OUT_PATH,species_name,df[df.accession==acc].protein_id.values[0]+'.pdb'),'w') as out:
                            out.writelines(response)
                except (URLError,RemoteDisconnected,HTTPError) as error:
                    not_found.append(acc)
        np.savetxt(os.path.join(OUT_PATH,species_name,'not_found.txt'), np.array(not_found), fmt="%s")

