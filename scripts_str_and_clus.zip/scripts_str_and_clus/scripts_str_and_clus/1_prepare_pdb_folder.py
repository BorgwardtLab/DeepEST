import os
import shutil

import numpy as np
import pandas as pd
from IPython import embed
from tqdm import tqdm


def main():
	info = pd.read_csv('../data/processed_files/splits/all_species/genes.txt',
		sep = " ", names = ["Locus", "Protein_id", "Species"])

	folder_in  = "../data/processed_files/structure/"
	folder_out = "../data/processed_files/structure/all_species/"
	
	if not(os.path.exists(folder_out)):
		os.mkdir(folder_out)
	
	for species, protein in tqdm(zip(info.Species, info.Protein_id)):
		pdb = "{}{}/{}.pdb".format(folder_in, species, protein)
		output = "{}{}.pdb".format(folder_out, protein)
		try:
			shutil.copyfile(pdb, output)
		except:
			print(pdb)


if __name__ == "__main__":
	main()