import os
import argparse

import numpy as np
import pandas as pd

from IPython import embed
from sklearn.model_selection import KFold
from tqdm import tqdm


def main(args):
	ordered_names = pd.read_csv('{}{}/genes.txt'.format(args.genes, args.species), 
		names = ["Locus_tag", "Protein_id", "No"], sep = " ")
	
	file = "{}cluster_all_species_cluster.tsv".format(args.clusters)
	clusters = pd.read_csv(file, sep = "\t", names = ["Representative", "Member"])
	
	clusters_dict = create_dict(clusters)

	label = "Protein_id"
	splits(clusters_dict, ordered_names, label, args)
	print('--------------')


def create_dict(clusters):
	clusters_dict = {}
	for representative in tqdm(clusters.Representative.unique()):
		tmp = clusters.Member.loc[clusters.Representative == representative].values
		members = [member.split('.pdb')[0] for member in tmp]
		clusters_dict[representative] = np.array(members)

	return clusters_dict


def splits(clusters_dict, ordered_names, label, args):
	if(not os.path.exists(args.outdir + args.species)): 
				os.makedirs(args.outdir + args.species)
	
	outer_cv = KFold(n_splits = args.folds, shuffle = True, random_state = args.seed)
	for fold, (train_index, test_index) in enumerate(outer_cv.split(np.zeros(len(clusters_dict)))):

		inner_cv = KFold(n_splits = args.folds - 1, shuffle = True, random_state = args.seed)
		train_inner_index, val_index = next(inner_cv.split(np.zeros(len(train_index)))) # returning just the first split

		# getting back to the actual indexes in the our dataset, i.e., the indexes according
		# to "ordered_genes" dataframe

		TRAIN = get_index(train_index[train_inner_index], ordered_names, clusters_dict, label)
		VAL   = get_index(train_index[val_index], ordered_names, clusters_dict, label)
		TEST  = get_index(test_index, ordered_names, clusters_dict, label)
		
		check(TRAIN, VAL, TEST, len(ordered_names))
		
		# saving splits
		np.save(args.outdir + args.species + '/train_index_{}.npy'.format(fold), TRAIN)
		np.save(args.outdir + args.species + '/val_index_{}.npy'.format(fold), VAL)
		np.save(args.outdir + args.species + '/test_index_{}.npy'.format(fold), TEST)



def get_index(index, ordered_names, clusters_dict, label):
	index_final = []
	cluster_id = np.array(list(clusters_dict.keys()))[index]
	for i in tqdm(cluster_id):
		cluster = clusters_dict[i]
		idx = []
		for c in cluster:
			indexes = np.where(ordered_names[label].values == c)[0].tolist()
			idx += indexes

		index_final += list(idx)

	return index_final



def check(train, val, test, L):
	tot = train + val + test
	if(len(np.unique(tot)) != L):
		raise NameError("Lengths do not match!")




def parse_arguments():
	'''
	Definition of the command line arguments
	'''
	parser = argparse.ArgumentParser()
	parser.add_argument('--genes', required = False, default =   '../data/processed_files/splits/')
	parser.add_argument('--clusters', required = False, default='../data/processed_files/clustering_foldseek/',
		help = 'clusters dir')
	parser.add_argument('--outdir', required = False, default='../data/processed_files/splits_foldseek/',
		help = 'output dir')
	parser.add_argument('--species', required = False, default='all_species',
		help = 'species')
	parser.add_argument('--seed', required = False, default=43, type = int,
		help = 'seed')
	parser.add_argument('--folds', required = False, default=5, type = int,
		help = 'folds')
	args = parser.parse_args()

	return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)