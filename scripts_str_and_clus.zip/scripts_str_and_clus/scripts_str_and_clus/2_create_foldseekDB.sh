mkdir /home/gmuzio/running_baselines_regression/data/processed_files/structure/all_species_foldseekDB/

PDB="/home/gmuzio/running_baselines_regression/data/processed_files/structure/all_species"
FOLDSEEK="/home/gmuzio/running_baselines_regression/data/processed_files/structure/all_species_foldseekDB/foldseekDB"
foldseek createdb $PDB $FOLDSEEK