DB="/home/gmuzio/running_baselines_regression/data/deepFRI_db/PDB-GO.tar.gz" # deepFRI dataset
QUERY="/home/gmuzio/running_baselines_regression/data/processed_files/structure/all_species/"
OUTFILE="comparison_deepFRI.m8"
OUTDIR="/home/gmuzio/running_baselines_regression/data/deepFRI_db"
foldseek easy-search $QUERY $DB $OUTFILE $OUTDIR --max-seqs 1000000000 --lddt-threshold "0.7" --format-output "query,target,lddt"
