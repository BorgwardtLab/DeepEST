INDIR="/home/gmuzio/running_baselines_regression/data/processed_files/structure/all_species/"
OUTFILE="cluster_all_species"
OUTDIR="/home/gmuzio/running_baselines_regression/data/processed_files/clustering_foldseek/all_species_foldseek_output"
foldseek easy-cluster $INDIR $OUTFILE $OUTDIR --max-seqs 1000000000 --lddt-threshold "0.7" 