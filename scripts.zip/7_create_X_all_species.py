import os
import re
import argparse

import pandas as pd
import numpy as np

from IPython import embed


def main(args):

	# Load the different species
	SPECIES = pd.read_csv('../data/species.txt')
	lessthan15 = np.loadtxt('../data/processed_files/splits/lessThan15genes.txt', dtype=str)

	all_files = []
	names = []
	for species in SPECIES.values:
		species = species[0]
		name = return_name(species)
		if (name not in lessthan15):
			print(species.split('.csv')[0])

			# the cleaned expression data path
			all_files.append('{}{}_genomic_info.csv'.format(args.inexp, name))
			names.append(name)
	
	df = pd.concat({f : my_import(f, n) for f, n in zip(all_files, names)})
	# reordering columns:
	df = df[['species', 'As vs. Ctrl - Log fold change', 'Bs vs. Ctrl - Log fold change',
	'Li vs. Ctrl - Log fold change', 'Mig vs. Ctrl - Log fold change',
	'Nd vs. Ctrl - Log fold change', 'Ns vs. Ctrl - Log fold change',
	'Oss vs. Ctrl - Log fold change', 'Oxs vs. Ctrl - Log fold change',
	'Sp vs. Ctrl - Log fold change', 'Tm vs. Ctrl - Log fold change',
	'Vic vs. Ctrl - Log fold change', 'cos-start', 'sin-start', 'cos-end',
	'sin-end', 'strand', 'genome']]
	
	df_imputed = df.fillna(df.mean(numeric_only = True))
	df_imputed.to_csv('{}/all_species_genomic_info.csv'.format(args.inexp))
	

def my_import(f, name):
	expression_data = pd.read_csv(f, index_col = 0)
	expression_data_sub = expression_data.drop(expression_data.columns[:2], axis='columns')
	expression_data_sub['species'] = len(expression_data_sub)*[name]
	return expression_data_sub


def return_name(infile):
	parts = infile.split('.csv')
	name = parts[0]
	return name.replace(' ', '_')



def parse_arguments():
	'''
	Definition of the command line arguments
	'''
	parser = argparse.ArgumentParser()
	parser.add_argument('--inraw', required = False, 
		help = 'Raw expression file path', default = '../data/OneDrive_1_2-1-2022/Gene expression and DEG files/')
	parser.add_argument('--inexp', required = False, 
		help = 'output dir processed expression data', default = '../data/processed_files/features/')
	args = parser.parse_args()

	return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)

