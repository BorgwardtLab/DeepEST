
import os
import math
import argparse
import resource
import statistics

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from IPython import embed
from tqdm import tqdm

def main(args):
	
	# Load the different species
	SPECIES = pd.read_csv('../data/species.txt')
	
	GO_terms = np.loadtxt(args.go + 'GO_terms_all_species.txt', dtype = str)
	genes_species_all = np.loadtxt(args.go + 'genes_all_species.txt', dtype = str)

	genes_species, out, unique = filter_species(genes_species_all)

	index = pd.MultiIndex.from_arrays([genes_species[:, 0], genes_species[:, 1]], names = ['genes', 'species'])
	Y = pd.DataFrame(data = np.zeros((len(genes_species), len(GO_terms))).astype(int), 
										index = index, columns = list(GO_terms))
	
	for species in SPECIES.values: 
		species = species[0]
		name = return_name(species)
		print(name)
		if ((not name in out) & (name in unique)):
			print(Y.values.sum())
			# obtaining a larger matrix per each species
			# larger ~ that contains all the GO terms (collected across species). 
			label_matrix_full = pd.read_csv('{}/label_matrix_{}_full_new.csv'.format(args.genes, name), 
				index_col = 0)
			diff = np.setdiff1d(GO_terms, list(label_matrix_full.keys()))
			if (len(diff) + len(list(label_matrix_full.keys())) != len(GO_terms)):
				print('\nERROR: something wrong with the GO terms\n')
			
			df_zeros = pd.DataFrame(data = np.zeros((len(label_matrix_full), len(diff))).astype(int), 
				columns = diff, index = label_matrix_full.index)
			full = pd.concat([label_matrix_full,df_zeros], axis = 1)
			
			# obtaining double index
			index = find_index(list(label_matrix_full.index), name)
			Y.loc[index] = full[Y.keys()].values
			
			print(Y.values.sum())
		else:
			print('Less than 10 genes.')
	

	gene_counts_terms = Y.sum(axis = 1)
	terms_count_gene = Y.sum()
	index_gene = gene_counts_terms > 0

	plt.figure()
	plt.hist(terms_count_gene, bins = 100)
	plt.savefig(args.outdir + 'plots/all_species.pdf')

	THRESHOLD = [5, 10, 50, 100]
	
	for thr in THRESHOLD:
		# drop terms with less than 10 genes
		index_term = ((terms_count_gene > thr) & (terms_count_gene < len(Y)))
		print('Threshold {}: {} proteins and {} GO terms'.format(thr, index_gene.sum(), index_term.sum()))
		
	index_term = terms_count_gene > THRESHOLD[1]

	Y[Y.keys()[index_term]].to_csv('{}/label_matrix_all_species_thr{}.csv'.format(args.outdir, THRESHOLD[1]))
	

def find_index(genes, species):
	tuples=[]
	for g in genes:
		tuples.append((str(g),species))
	
	index = pd.MultiIndex.from_tuples(tuples, names=["genes", "species"])
	return index


	
def filter_species(genes_species_all):
	sp, c = np.unique(genes_species_all[:, 1], return_counts = True)
	sp_out = sp[c <= 15]

	index = np.array(len(genes_species_all)*[True])
	for so in sp_out:
		idx_so = genes_species_all[:, 1] == so
		index[idx_so] = False

	return genes_species_all[index], sp_out, np.unique(genes_species_all[:, 1])


def return_name(infile):
	parts = infile.split('.csv')
	name = parts[0]
	return name.replace(' ', '_')


def parse_arguments():
	'''
	Definition of the command line arguments
	'''
	parser = argparse.ArgumentParser()
	parser.add_argument('--go', required = False, default = "../data/GOTerms_new/",
		help = 'go terms file')
	parser.add_argument('--outdir', required = False, default = "../data/processed_files/matrix_label/",
		help = 'output dir')
	parser.add_argument('--genes', required = False, default = "../data/processed_files/matrix_label/",
		help = 'genes for which we have expression')
	parser.add_argument('--genenames', required = False, default = "../data/OneDrive_1_2-1-2022/Gene\ expression\ and\ DEG\ files/",
		help = 'raw data with mapping among gene names')
	args = parser.parse_args()

	return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)