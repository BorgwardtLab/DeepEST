import os
import argparse

import pandas as pd
import numpy as np
from tqdm import tqdm

from IPython import embed

import sys
sys.path.insert(1, '../')

from src.utils import load_pickle, performance_assessment
from src.utils_deepgoplus import update_scores



def main(args):
	# print(args.X)
	
	X_df = pd.read_csv(args.X,    )
	Y_df = pd.read_csv(args.label)
	X=X_df.values
	Y = Y_df.values
	# print(X.shape)
	# print(Y.shape)
	name = args.X.split('features/')[1].split('_genomic_info_NN.csv')[0]
	inputs = X.shape[1]
	genes = X.shape[0]
	goterms = Y.shape[1]
	print('{}\t{}\t{}\t{}'.format(name, inputs, genes, goterms))
	#print('{}\t{}'.format(name,goterms))


	




def parse_arguments():
	'''
	Definition of the command line arguments
	'''
	parser = argparse.ArgumentParser()
	parser.add_argument('--X', required = True,
		help = 'feature matrix')
	parser.add_argument('--label', required = True,
		help = 'label matrix')
	args = parser.parse_args()

	return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)
