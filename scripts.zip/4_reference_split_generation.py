'''
This script does two operations:
1) construct the feature matrix by removing the lines (genes/proteins) where 
there is not GO terms annotated 
2) create the reference for the indexing of the training, validation and test set
'''


import os
import math
import argparse
import resource
import statistics

import pandas as pd
import numpy as np

from IPython import embed

	

def main(args):
	fold_num = 5
	
	labels = np.loadtxt(args.labellist + 'label_list.txt', dtype = str)
	toofew = []
	
	for label in labels:
	#for label in ['label_matrix_Shigella_flexneri_5a_str._M90T_new_thr10_new.csv']:
		name = return_name(label)
		
		# Loading the label matrix
		Y = pd.read_csv(args.labellist + label, index_col = 0)

		if(len(Y) > 15):
			if(not os.path.exists(args.outdir + '/' + name)): 
				os.makedirs(args.outdir + name)

			# Loading the expression matrix. This is done because we 
			# need the protein id, which we stored there.
			# We also use this occasion to removed the proteins for 
			# which we do not have GO terms.
			X = pd.read_csv('{}/{}.csv'.format(args.expr, name), index_col = 0)
			sub = X.loc[Y.index]
			sub.to_csv('{}/{}.csv'.format(args.feat, name))

						
			np.save('{}{}/genes.npy'.format(args.outdir, name), np.array(list(Y.index)))
			np.savetxt('{}{}/genes.txt'.format(args.outdir, name), np.c_[ np.array(list(Y.index)), sub[sub.keys()[:2]].loc[Y.index].values ], fmt='%s')
					
		else:
			toofew.append(name)

	np.savetxt('{}lessThan15genes.txt'.format(args.outdir), toofew, fmt='%s')


def check_multiple(test_index, train_index, val_index, sub, Y):
	p_test=sub.iloc[test_index]['Protein_id']
	p_train=sub.iloc[train_index]['Protein_id']
	p_val=sub.iloc[val_index]['Protein_id']
	if(np.all(sub.index==Y.index)):
		int1 = np.intersect1d(p_test.astype(str), p_train.astype(str))
		int2 = np.intersect1d(p_train.astype(str), p_val.astype(str))
		int3 = np.intersect1d(p_test.astype(str), p_val.astype(str))
		if((len(int1)>0) | (len(int2)>0) | (len(int3)>0)):
			print('Something wrong! The copies are in different folds!')


def left_out_mapping(Y, sub_Y, sub, multiple, fold_index):
	# adding the left out locus tag
	ID_test = np.array(list(sub_Y.index))[fold_index]
	P_test  = sub['Protein_id'].loc[ID_test]
	inter   = np.intersect1d(P_test, multiple)
	
	for i in inter:
		additional = list(sub['Protein_id'].loc[sub['Protein_id']==i].index)
		ID_test = np.concatenate((ID_test, additional))

	ID_test = np.unique(ID_test) # from this, I have to get back the index in the 
	# entire label matrix
	inter, I, index_tot = np.intersect1d(ID_test, list(Y.index), return_indices = True)
	return index_tot


def dummy_label(Y, nfolds):
	counts = Y.sum(axis = 1) # number of labels per gene

	number = np.unique(counts)

	# we are merging together genes with "close" numerosity
	# of terms they are annotated with.
	flag = True
	step = 2

	while(flag):
		low = np.arange(0, max(number), step)
		top = np.arange(step, max(number) + step, step)

		dummy = np.zeros(len(Y))
		for i, (l, t) in enumerate(zip(low, top)):
			numbers = number[(number >= l) & (number < t)]
			for n in numbers:
				dummy[counts == n] = i
		
		un, ct = np.unique(dummy, return_counts = True)
		if(sum(ct < nfolds) > 0):
			step += 1
		else:
			flag = False

	return dummy

		

def return_name(filename):
	return filename.split('label_matrix_')[1].split('_thr10_new.csv')[0]
	

def parse_arguments():
	'''
	Definition of the command line arguments
	'''
	parser = argparse.ArgumentParser()
	parser.add_argument('--labellist', required = False, default='../data/processed_files/matrix_label/',
		help = 'label matrix list \
		the stratified split')
	parser.add_argument('--expr', required = False, default =   '../data/processed_files/expr/')
	parser.add_argument('--feat', required = False, default =   '../data/processed_files/features/')
	parser.add_argument('--outdir', required = False, default='../data/processed_files/splits/',
		help = 'output dir')
	parser.add_argument('--seed', required = False, default=42, type = int,
		help = 'seed')
	args = parser.parse_args()

	return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)