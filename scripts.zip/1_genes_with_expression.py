"""
This script performs a first filtering of the 
genes to the ones that have the expression 
recorded.
"""

import os
import math
import argparse
import resource
import statistics

import pandas as pd
import numpy as np

from IPython import embed

def main(args):

	if(not os.path.exists(args.outdirexp)): 
		os.makedirs(args.outdirexp)


	# Load the different species
	SPECIES = pd.read_csv('../data/species.txt')
	
	missing_structures = pd.read_csv("../data/processed_files/structure/missing_structures.txt", header=None)
	# Extract and save the expressin values of interest
	# from the raw file
	for species in SPECIES.values:
	#for species in ['Shigella flexneri 5a str. M90T_new.csv']:
		species = species[0]
		raw_data = pd.read_csv(args.infolder + species,  sep = ';', low_memory=False)
		if ((species == 'Shigella flexneri 5a str. M90T_new.csv') & (len(np.unique(raw_data.No.values)) == 1 ) ):
			# the line identified is the same across genes, unlike for the other species
			# so, we modify it by replacing it with the counts.
			raw_data.No = np.arange(raw_data.No.values[0], raw_data.No.values[0] + len(raw_data) )
			raw_data.to_csv(args.infolder + species, sep = ";", index = None)
		
		removed_zero_expr = clean_expression(raw_data)
		expression_data = filter_columns(removed_zero_expr)
		if (species == 'Shigella flexneri 5a str. M90T_new.csv'):
			expression_data = string2float(expression_data)
		
		name = return_name(species)
		# remove the genes for which it's not possible to find a structure
		intersection = np.intersect1d(missing_structures, expression_data.Protein_id.dropna())
		index_tot = []
		for remove_p in intersection:
			idx = np.where(expression_data.Protein_id.values == remove_p)[0]
			index_tot +=  expression_data.index[idx].tolist()

		expression_data = expression_data.drop(index=index_tot)
		#NP_465191.1
		expression_data.to_csv('{}/{}.csv'.format(args.outdirexp, name), index = False)


def string2float(df):
	vect=get_vect()
	values = df[vect].values
	n,m=values.shape
	for i in range(n):
		for j in range(m):
			values[i,j]=values[i,j].replace(",", ".")
	df2=df.copy()
	for i in range(len(vect)):
		df2[vect[i]] = values[:, i].astype(float)
		
	df2[vect]=df2[vect].astype(float)
	return df2


def get_vect():
	return  ['As vs. Ctrl - Log fold change','Bs vs. Ctrl - Log fold change', 'Li vs. Ctrl - Log fold change',
	'Mig vs. Ctrl - Log fold change', 'Nd vs. Ctrl - Log fold change',
	'Ns vs. Ctrl - Log fold change', 'Oss vs. Ctrl - Log fold change',
	'Oxs vs. Ctrl - Log fold change', 'Sp vs. Ctrl - Log fold change',
	'Tm vs. Ctrl - Log fold change', 'Vic vs. Ctrl - Log fold change']

def clean_expression(expression_data):
	# it seems that there are lines that contains
	# only #NUM!. So, as a first step I am gonna remove these.
	# Focus only on the first column, to make things faster
	col = expression_data['As vs. Ctrl - Log fold change']
	indexes = np.where(col == '#NUM!')[0]
	expression_data = expression_data.drop(indexes).copy()
	indexes_nan = np.where(pd.isnull(col))[0]
	expression_data = expression_data.drop(indexes_nan).copy()
	return expression_data


def return_name(infile):
	parts = infile.split('.csv')
	name = parts[0]
	return name.replace(' ', '_')


def filter_columns(raw_data):
	'''
	function to filter out the columns with the expression
	of the stress condition vs the control condition
	'''
	columns = np.array(list(raw_data.keys()))
	if (raw_data['New_locus_tag'].isnull().sum() == 0):
		keep = ['New_locus_tag', 'Protein_id', "No"]
	else:
		keep = ['Old_locus_tag', 'Protein_id', "No"]

	for c in columns:
		# we are keeping the log of the condition vs control
		if 'Log fold change' in c: 
			keep.append(c)
		
	return raw_data[keep]



def parse_arguments():
	'''
	Definition of the command line arguments
	'''
	parser = argparse.ArgumentParser()
	parser.add_argument('--infolder', required = False, 
		help = 'Raw expression file path', default = '../data/OneDrive_1_2-1-2022/Gene expression and DEG files/')
	parser.add_argument('--outdirexp', required = False, 
		help = 'output dir processed expression data', default = '../data/processed_files/expr/')
	args = parser.parse_args()

	return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)

