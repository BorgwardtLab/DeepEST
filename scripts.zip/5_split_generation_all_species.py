
import os
import math
import argparse
import resource
import statistics

import pandas as pd
import numpy as np

from IPython import embed
from sklearn.model_selection import StratifiedKFold
	

def main(args):

	if(not os.path.exists(args.outdir)): 
		os.makedirs(args.outdir)
	
	fold_num = 5

	Y = pd.read_csv(args.label)
	
	prot_id = get_protein_id(Y, args)
	Y['Protein_id'] = prot_id

	# check whether there are multiple copies of genes (i.e., same encoded protein)
	un, index, counts = np.unique(Y['Protein_id'], return_index = True, return_counts = True)
	multiple = un[counts > 1]

	sub_Y = Y.iloc[index] # with no duplicates
	
	# stratification vector based on the number of
	# GO terms per gene and the species
	strat_by = dummy_label(sub_Y, fold_num)
	print(strat_by)
	outer_cv = StratifiedKFold(n_splits = fold_num, shuffle = True, random_state = args.seed)
	
	check = np.array([])

	for fold, (train_index_small, test_index_small) in enumerate(outer_cv.split(np.zeros(len(strat_by)), strat_by)):
		test_index = left_out_mapping(Y, sub_Y, multiple, test_index_small)
		check = np.concatenate((check, test_index))
		np.save('{}/test_index_{}.npy'.format(args.outdir, fold), test_index)
		

		strat_by_train = strat_by[train_index_small]
		
		inner_cv = StratifiedKFold(n_splits = fold_num - 1, shuffle = True, random_state = args.seed)
		train_inner_index_small, val_index_small = next(inner_cv.split(np.zeros(len(strat_by_train)), strat_by_train)) # returning just the first split
		
		train_index = left_out_mapping(Y, sub_Y, multiple, train_index_small[train_inner_index_small])
		val_index   = left_out_mapping(Y, sub_Y, multiple, train_index_small[val_index_small])
		
		np.save('{}/train_index_{}.npy'.format(args.outdir, fold), train_index)
		np.save('{}/val_index_{}.npy'.format(args.outdir, fold), val_index)
		check_multiple(test_index, train_index, val_index, Y)
		check_indexes(test_index, train_index, val_index, Y)
	
	
	np.save('{}/genes.npy'.format(args.outdir), Y[['genes', "Protein_id", 'species']].values)
	np.savetxt('{}/genes.txt'.format(args.outdir), Y[['genes', "Protein_id", 'species']].values, fmt="%s")
	check_test(check, Y)


def check_test(check, Y):
	if (len(np.unique(check)) != len(Y)):
		print('Something wrong with test set!')
		


def check_indexes(train, test, val, Y):
	tot = np.concatenate((train, test, val))
	inter = np.intersect1d(tot, Y.index)
	if(len(inter) != len(Y.index)):
		print('Something odd in the splits!')


def check_multiple(test_index, train_index, val_index, Y):
	p_test=Y['Protein_id'].iloc[test_index]
	p_train=Y['Protein_id'].iloc[train_index]
	p_val=Y['Protein_id'][val_index]

	int1 = np.intersect1d(p_test.astype(str), p_train.astype(str))
	int2 = np.intersect1d(p_train.astype(str), p_val.astype(str))
	int3 = np.intersect1d(p_test.astype(str), p_val.astype(str))
	if((len(int1)>0) | (len(int2)>0) | (len(int3)>0)):
		print('Something wrong! The copies are in different folds!')



def left_out_mapping(Y, sub_Y, multiple, fold_index):
	
	# adding the left out locus tag
	ID_test = sub_Y[['genes', 'species']].iloc[fold_index].values
	P_test  = sub_Y['Protein_id'].iloc[fold_index].values
	inter   = np.intersect1d(P_test, multiple)

	for i in inter:
		additional = Y[['genes', 'species']].loc[Y['Protein_id']==i].values
		ID_test = np.concatenate((ID_test, additional))

	ID_test = np.unique(ID_test.astype(str), axis=0) # from this, I have to get back the index in the 
	# entire label matrix
	
	ID_test_label = [str(i) + str(j) for i, j in zip(ID_test[:, 0], ID_test[:, 1])]
	Y_label = [str(i) + str(j) for i, j in zip(Y['genes'].values, Y['species'].values)]
	inter, I, index_tot = np.intersect1d(ID_test_label, Y_label, return_indices = True)
	return index_tot


def find_index(ID_test):
	tuples=[]
	for g in genes:
		tuples.append((str(g),species))
	
	index = pd.MultiIndex.from_tuples(tuples, names=["genes", "species"])
	return index


def get_protein_id(Y, args):
	species = np.unique(Y['species'])
	prots = np.array([])
	for s in species:
		X = pd.read_csv('{}/{}.csv'.format(args.feat, s), index_col = 0)
		sub_Y = Y[['genes', 'species']].loc[Y['species'] == s]
		if ( np.all(sub_Y['genes'].values==X.index) ):
			prots = np.concatenate((prots, X['Protein_id'].values))
		else:
			print('Something odd.')
	return prots


def dummy_label(Y, nfolds):
	counts = Y.values[:, 2:-1].sum(axis = 1) # number of labels per gene
	species = Y['species'].values

	# we are merging together genes with "close" numerosity
	# of terms they are annotated with.
	

	dummy_sp_num = species.copy()

	for j, sp in enumerate(np.unique(species)):
		index = species == sp
		dummy_sp_num[index] = str(j)
		
		counts_sp = counts[index]
		number = np.unique(counts_sp)
		
		flag = True
		step = 2
		
		while(flag):
			low = np.arange(0, max(number), step)
			top = np.arange(step, max(number) + step, step)

			dummy = np.zeros(sum(index)).astype(int)
			for i, (l, t) in enumerate(zip(low, top)):
				numbers = number[(number >= l) & (number < t)]
				for n in numbers:
					dummy[counts_sp == n] = i
			
			un, ct = np.unique(dummy, return_counts = True)
			if(sum(ct < nfolds) > 0):
				step += 1
			else:
				dummy_sp_num[index] += dummy.astype(str)
				flag = False

	return dummy_sp_num

		

def return_name(filename):
	return filename.split('label_matrix_')[1].split('_thr10.csv')[0]
	

def parse_arguments():
	'''
	Definition of the command line arguments
	'''
	parser = argparse.ArgumentParser()
	parser.add_argument('--label', required = False, default='../data/processed_files/matrix_label/label_matrix_all_species_thr10.csv',
		help = 'label matrix list')
	parser.add_argument('--feat', required = False, default =   '../data/processed_files/features/')
	parser.add_argument('--outdir', required = False, default='../data/processed_files/splits/all_species/',
		help = 'output dir')
	parser.add_argument('--seed', required = False, default=42, type = int,
		help = 'seed')
	args = parser.parse_args()

	return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)