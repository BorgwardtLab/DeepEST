
import os
import math
import argparse
import resource
import statistics

import pandas as pd
import numpy as np

from IPython import embed
from sklearn.model_selection import StratifiedKFold
	

def main(args):

	if(not os.path.exists(args.outdir)): 
		os.makedirs(args.outdir)
	
	fold_num = 5

	Y = pd.read_csv(args.label)
	
	prot_id = get_protein_id(Y, args)
	Y['Protein_id'] = prot_id
	
	
	np.save('{}/genes.npy'.format(args.outdir), Y[['genes', "Protein_id", 'species']].values)
	np.savetxt('{}/genes.txt'.format(args.outdir), Y[['genes', "Protein_id", 'species']].values, fmt="%s")
	




def get_protein_id(Y, args):
	species = np.unique(Y['species'])
	prots = np.array([])
	for s in species:
		X = pd.read_csv('{}/{}.csv'.format(args.feat, s), index_col = 0)
		sub_Y = Y[['genes', 'species']].loc[Y['species'] == s]
		if ( np.all(sub_Y['genes'].values==X.index) ):
			prots = np.concatenate((prots, X['Protein_id'].values))
		else:
			print('Something odd.')
	return prots


		

def return_name(filename):
	return filename.split('label_matrix_')[1].split('_thr10.csv')[0]
	

def parse_arguments():
	'''
	Definition of the command line arguments
	'''
	parser = argparse.ArgumentParser()
	parser.add_argument('--label', required = False, default='../data/processed_files/matrix_label/label_matrix_all_species_thr10.csv',
		help = 'label matrix list')
	parser.add_argument('--feat', required = False, default =   '../data/processed_files/features/')
	parser.add_argument('--outdir', required = False, default='../data/processed_files/splits/all_species/',
		help = 'output dir')
	parser.add_argument('--seed', required = False, default=42, type = int,
		help = 'seed')
	args = parser.parse_args()

	return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)