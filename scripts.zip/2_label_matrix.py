import os
import math
import argparse
import resource
import statistics
import pickle

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from IPython import embed


def main(args):

	if(not os.path.exists(args.outdir)): 
		os.makedirs(args.outdir)
	
	# Load the different species
	SPECIES = pd.read_csv('../data/species.txt')
	
	GO_tot_all_species = np.array([])
	anc_dict_all_species = {}
	gene_all_species = np.array([])
	species_all = np.array([])
	
	for species in SPECIES.values:
		species = species[0]
		
		name = return_name(species)
		print(name)

		# Loading files
		terms_ancestors = pd.read_csv(args.go + name + '_GO_terms_with_ancestors.csv',
												    index_col = 0, low_memory = False)
		genes_df  = pd.read_csv(args.genes + name + '.csv')
		
		genes = genes_df['No'].values

		go_label, ancestor_label, terms, ancestors = separate_go_ancestors(terms_ancestors)
		ancestors_dictionary = find_ancestors_dictionary(terms, ancestors, go_label, ancestor_label)
		anc_dict_all_species = {**anc_dict_all_species,**ancestors_dictionary}

		GO_tot = go_list(terms, ancestors)
		GO_tot_all_species = np.concatenate((GO_tot_all_species, GO_tot))
		GO_tot_all_species = np.unique(GO_tot_all_species)
		
		THRESHOLD = [5, 10, 50, 100]
		
		label_matrix_full, label_matrix, not_g, terms_count_gene = find_label(
			genes, GO_tot, terms, ancestors_dictionary, THRESHOLD)
		# Update index of the label matrix; default old locus tag, if not present, then new one
		label_matrix_full, label_matrix = update_index(
			label_matrix_full, label_matrix, genes, genes_df)

		# plt.figure()
		# plt.hist(terms_count_gene, bins = 50)
		# plt.savefig(args.outdir + '/' + name + '.pdf')
		gene_all_species = np.concatenate((gene_all_species, np.array(label_matrix.index)))
		species_all = np.concatenate((species_all, np.full(len(np.array(label_matrix.index)), name)))
		#if (species == 'Shigella flexneri 5a str. M90T_new.csv'): 
		label_matrix.to_csv('{}/label_matrix_{}_thr{}_new.csv'.format(args.outdir, name, THRESHOLD[1]))
		label_matrix_full.to_csv('{}/label_matrix_{}_full_new.csv'.format(args.outdir, name))
		print('-------------------------------------------\n')

	print('{} unique GO terms across species.'.format(len(GO_tot_all_species)))
	print(len(gene_all_species))
	np.savetxt(args.go + 'GO_terms_all_species.txt', GO_tot_all_species, fmt='%s')
	np.savetxt(args.go + 'genes_all_species.txt', np.c_[gene_all_species, species_all], fmt='%s')
	save_pickle(args.go + 'dictionary_all_species.pkl', anc_dict_all_species)
	

def update_index(mat_full, mat, genes, genes_df):
	df = genes_df.copy()
	df = df.set_index(df.No)

	sub = df.loc[mat.index]
	if ("Old_locus_tag" in sub.keys()):
		if(sum(pd.isnull(sub.Old_locus_tag)) == 0):
			return mat_full.set_index(sub.Old_locus_tag), mat.set_index(sub.Old_locus_tag) 
		elif(sum(pd.isnull(sub.New_locus_tag)) == 0):
			return mat_full.set_index(sub.New_locus_tag), mat.set_index(sub.New_locus_tag) 
		else:
			print("OI...")
	else:
		return mat_full.set_index(sub.New_locus_tag), mat.set_index(sub.New_locus_tag) 
		


def save_pickle(filename, data):
	with open(filename, 'wb') as f:
		pickle.dump(data, f, pickle.HIGHEST_PROTOCOL)


def return_name(infile):
	parts = infile.split('.csv')
	name = parts[0]
	return name.replace(' ', '_')


def find_label(genes, GO_tot, terms, ancestors, THRESHOLD):
	Y = pd.DataFrame(data = np.zeros((len(genes), len(GO_tot))).astype(int), index = genes, columns = GO_tot)
	not_g = []
	for g in genes:
		terms_gene = find_term(g, terms)
		if (len(terms_gene) > 0):
			# find uncestors
			terms_gene_plusA = find_ancestors(terms_gene, ancestors, not_g)
			# update label matrix
			for t in terms_gene_plusA:
				Y.at[g, t] = 1
	
	# drop genes with no terms
	index_gene = Y.sum(axis = 1) > 0
	terms_count_gene = Y.sum()
	
	for thr in THRESHOLD:
		# drop terms with less than thr genes
		index_term = ((terms_count_gene > thr) & (terms_count_gene < index_gene.sum()))
		print('Threshold {}: {} proteins and {} GO terms'.format(thr, index_gene.sum(), index_term.sum()))
	
	index_term = terms_count_gene > THRESHOLD[1] # 10 as threshold
	return Y.loc[index_gene].copy(), Y[GO_tot[index_term]].loc[index_gene].copy(), not_g, terms_count_gene


def find_ancestors(terms_gene, ancestors, not_g):
	anc_tot = terms_gene
	for g in terms_gene:
		if g in ancestors.keys():
			anc = ancestors[g]
			anc_tot = np.concatenate((anc_tot, anc))
		else:
			not_g.append(g)

	return np.unique(anc_tot)


def find_ancestors_dictionary(terms, ancestors, child_label, ancestors_labels):
	values = terms.values
	children = np.unique(values[np.logical_not(pd.isnull(values))])
	ancestors_values = ancestors.values

	anc_dict = {}
	for child in children:
		ix_, iy_ = np.where(values == child)
		# we take the first occurence and the
		# stored ancestors are the same
		ix = ix_[0] # row of the "ancestors_values" matrix
		iy = iy_[0] # this tells us the columns to check, i.e., ancestor_XX_term_iy
		columns_idx = check_labels(ancestors_labels, iy)
		all_anc = ancestors_values[ix, columns_idx]
		anc_child = all_anc[np.logical_not(pd.isnull(all_anc))]
		anc_dict[child] = np.setdiff1d(anc_child, child)

	return anc_dict


def check_labels(ancestors_labels, iy):
	string = "term_{}".format(iy)
	idx_match = [i for i, s in enumerate(ancestors_labels) if s.__contains__(string)]
	return idx_match


def find_term(gene_id, terms):
	return terms.loc[gene_id][terms.loc[gene_id].notnull()].values


def go_list(terms, ancestors):
	vt = clean(terms)
	va = clean(ancestors)
	return np.unique(np.concatenate((vt, va)))

def clean(v):
	values = v.values
	index_not_nan = np.logical_not(pd.isnull(values))
	terms = np.unique(values[index_not_nan])
	return terms

def separate_go_ancestors(terms_ancestors):
	columns = np.array(list(terms_ancestors.keys()))

	go_label, ancestor_label = [], []
	for c in columns:
		if('GO_' in c):
			go_label.append(c)
		else:
			ancestor_label.append(c)
	
	return go_label, ancestor_label, terms_ancestors[go_label].copy(), terms_ancestors[ancestor_label].copy()


def parse_arguments():
	'''
	Definition of the command line arguments
	'''
	parser = argparse.ArgumentParser()
	parser.add_argument('--go', required = False, default = "../data/GOTerms_new/", 
		help = 'go terms file')
	parser.add_argument('--outdir', required = False, default = "../data/processed_files/matrix_label", 
		help = 'output dir')
	parser.add_argument('--genes', required = False, default = "../data/processed_files/expr/", 
		help = 'genes for which we have expression')
	parser.add_argument('--genenames', required = False, default = "../data/OneDrive_1_2-1-2022/Gene\ expression\ and\ DEG\ files/", 
		help = 'raw data with mapping among gene names')
	args = parser.parse_args()

	return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)