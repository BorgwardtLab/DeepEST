'''
Run this script after having performed the hyperparameter search.
Indeed, this is the script that generates the config files with 
the optimal hyperparameter configuration per each species, fold, 
and split type, to run on the test set.
'''

import os
import re
import argparse
import yaml

import pandas as pd
import numpy as np

from IPython import embed


def main():

	data = np.loadtxt('../data/processed_files/details_species.txt', dtype=str)
	
	with open("../src/config_exp.yaml") as f:
		list_doc = yaml.safe_load(f)

	for fold in range(5):
		for split in ["splits_foldseek"]:#["splits", "splits_cdhit"]:
			for species in data[:, 0]:
				info = data[data[:, 0] == species][0]
				list_species = list_doc.copy()

				# get the hyperparameters per each fold and split
				batch_size, hidden_sizes, learning_rate, droup_out, weight_decay = get_hyperparameters(
					fold, split, info)
				
				# updating the hyperparameters
				list_species['model_params']['input_dim'] = int(info[1])
				list_species['model_params']['hidden_sizes'] = hidden_sizes
				list_species['model_params']["lr"] = learning_rate
				list_species['model_params']["p"]  = droup_out
				list_species['model_params']["weight_decay"] = weight_decay
				list_species['data_params']["batch_size"] = batch_size

				folder = "../src/config_species/{}_fold{}/".format(split, fold)
				if (not os.path.exists(folder)):
					os.mkdir(folder)
				
				with open("{}config_exp_{}.yaml".format(folder, species), "w") as f:
					yaml.dump(list_doc, f)


def get_hyperparameters(fold, split, info):
	if (split == "splits"):
		batch_size = 32
		hidden_sizes = [512, 16, 512]
		learning_rate = 0.0001
		droup_out = 0.0
		weight_decay = 0.0
	elif(split == "splits_cdhit"):
		if(fold != 3):
			batch_size = 32
			hidden_sizes = [32, 128, 32, 128]
			learning_rate = 0.0001
			droup_out = 0.25
			weight_decay = 0.01
		else:
			batch_size = 32
			hidden_sizes = [32, 64, 128, 256, 512]
			learning_rate = 0.0001
			droup_out = 0.25
			weight_decay = 0.01
	else:
		batch_size = 128
		learning_rate = 0.0001
		weight_decay = 0.01
		if (fold == 3):
			hidden_sizes = [32, 64, 128, 256, 512]
		elif(fold == 4):
			hidden_sizes = [34, 68, 136, 272]
		else:
			hidden_sizes = [32, 64, 128]

		if((fold == 2) or (fold == 4)):
			droup_out = 0.0
		else:
			droup_out = 0.25

	hidden_sizes += [int(info[-1])]
	return batch_size, hidden_sizes, learning_rate, droup_out, weight_decay



if __name__ == '__main__':
    main()