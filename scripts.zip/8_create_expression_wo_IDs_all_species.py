import os
import re
import argparse

import pandas as pd
import numpy as np

from IPython import embed


def main(args):
    name = 'all_species'
    # the cleaned expression data path
    f ='{}{}_genomic_info.csv'.format(args.inexp, name) 
    
    expression_data = pd.read_csv(f, index_col = (1,2))
    expression_data = expression_data.drop([ 'Unnamed: 0'], axis='columns')
    print(expression_data.columns)
    
    filename='../data/processed_files/matrix_label/label_matrix_{}_thr10.csv'.format(name)
    Y = pd.read_csv(filename, index_col = (0,1))
    # remove NaNs
    null = np.where(expression_data.isnull().sum() > 0)[0]
    print(null)
    if(len(null) > 0):
        cols = list(expression_data.columns)
        for n in null:
            expression_data =  expression_data.drop(cols[n], axis='columns')
    print(expression_data.shape)
    assert (Y.index==expression_data.index).all()
    Y.to_csv('../data/processed_files/matrix_label/label_matrix_{}_thr10_NN.csv'.format(name), index=None)
    print(Y.shape)
    expression_data.to_csv('{}{}_genomic_info_NN.csv'.format(args.inexp, name), index=None)





def parse_arguments():
    '''
    Definition of the command line arguments
    '''
    parser = argparse.ArgumentParser()
    parser.add_argument('--inraw', required = False, 
        help = 'Raw expression file path', default = '../data/OneDrive_1_2-1-2022/Gene expression and DEG files/')
    parser.add_argument('--inexp', required = False, 
        help = 'output dir processed expression data', default = '../data/processed_files/features/')
    args = parser.parse_args()

    return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)
