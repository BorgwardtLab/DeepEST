import os
import re
import argparse

import pandas as pd
import numpy as np

from IPython import embed


def main(args):

	# Load the different species
	SPECIES = pd.read_csv('../data/species.txt')
	lessthan15 = np.loadtxt('../data/processed_files/splits/lessThan15genes.txt', dtype=str)

	all_files = []
	names = []
	for species in SPECIES.values:
                species = species[0]
                name = return_name(species)
                index_col = 0
                if (name not in lessthan15):
                    #print(species.split('.csv')[0])
                    # the cleaned expression data path
                    f ='{}{}_genomic_info.csv'.format(args.inexp, name)
                    expression_data = pd.read_csv(f, index_col = index_col)
                    expression_data_sub = expression_data.drop(expression_data.columns[:2], axis='columns')

                    filename='../data/processed_files/matrix_label/label_matrix_{}_thr10_new.csv'.format(name)
                    Y = pd.read_csv(filename, index_col = index_col)
                    # remove NaNs
                    null = np.where(expression_data_sub.isnull().sum() > 0)[0]
                    print(null)
                    if(len(null) > 0):
                        cols = list(expression_data_sub.columns)
                        for n in null:
                            expression_data_sub =  expression_data_sub.drop(cols[n], axis='columns')
                    print(expression_data_sub.shape)
                    assert (Y.index==expression_data_sub.index).all()
                    Y.to_csv('../data/processed_files/matrix_label/label_matrix_{}_thr10_NN.csv'.format(name), index=None)
                    expression_data_sub.to_csv('{}{}_genomic_info_NN.csv'.format(args.inexp, name), index=None)


def return_name(infile):
	parts = infile.split('.csv')
	name = parts[0]
	return name.replace(' ', '_')



def parse_arguments():
	'''
	Definition of the command line arguments
	'''
	parser = argparse.ArgumentParser()
	parser.add_argument('--inraw', required = False, 
		help = 'Raw expression file path', default = '../data/OneDrive_1_2-1-2022/Gene expression and DEG files/')
	parser.add_argument('--inexp', required = False, 
		help = 'output dir processed expression data', default = '../data/processed_files/features/')
	args = parser.parse_args()

	return args


if __name__ == '__main__':
    arguments = parse_arguments()
    main(arguments)

